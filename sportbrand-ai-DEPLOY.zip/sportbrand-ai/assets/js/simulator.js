'use strict';

/* Simulator de creștere.
   Refolosește motorul real din scoring.js. Utilizatorul mișcă parametri
   (urmăritori, frecvență, nivel, public, ofertă, rezultate) și vede în timp
   real cum se schimbă scorul și valoarea estimată pentru sponsor — plus un
   plan concret de 90 de zile pentru a ajunge de la profilul curent la cel
   simulat. 100% static: nicio cerere de rețea, doar recalcul instant. */

window.SBAI = window.SBAI || {};

(function simulator() {
  const sb = window.SBAI;
  const C = 2 * Math.PI * 52; // circumferința inelului (r=52)
  const FOLLOWERS_MAX_EXP = 5; // 10^5 = 100.000

  const LEVEL_LABEL = {
    junior: 'Junior', amator: 'Amator', 'semi-pro': 'Semi-profesionist',
    profesionist: 'Profesionist', 'lot-national': 'Lot național', olimpic: 'Olimpic'
  };
  const LEVEL_ORDER = ['junior', 'amator', 'semi-pro', 'profesionist', 'lot-national', 'olimpic'];
  const FREQ_LABEL = { low: '1–2 postări/săpt', medium: '3–4 postări/săpt', high: '5+ postări/săpt' };
  const FREQ_ORDER = ['low', 'medium', 'high'];
  const AUD_LABEL = {
    local: 'comunitate locală', juniori: 'copii / juniori / părinți',
    performanta: 'sportivi de performanță', lifestyle: 'lifestyle / wellness', corporate: 'companii / corporate'
  };
  const AUD_RELEVANCE = { corporate: 100, performanta: 90, local: 80, juniori: 72, lifestyle: 66 };

  // Texte „îmbogățite" folosite de comutatoare, ca sub-scorurile bazate pe text
  // (rezultate, ofertă) să reflecte îmbunătățirea reală prin motorul existent.
  const STRONG_ASSETS = 'logo pe echipament și materiale, postări dedicate săptămânal, story-uri, apariții video, prezență la evenimente, drept de folosire a imaginii, newsletter și comunitate locală activă, pachet clar de livrabile pentru sponsor';
  const STRONG_RESULTS = 'palmares documentat cu clasamente și diplome, participări relevante, 2 testimoniale (antrenor și club), progres competițional dovedit pas cu pas';

  let el = {};
  let baseline = null;   // datele profilului curent
  let baseScore = null;  // scorul profilului curent

  const $ = (id) => document.getElementById(id);

  function followersToSlider(f) {
    const n = Math.max(0, Number(f) || 0);
    if (n <= 0) return 0;
    return Math.round((Math.log10(n) / FOLLOWERS_MAX_EXP) * 100);
  }
  function sliderToFollowers(s) {
    const v = Math.max(0, Math.min(100, Number(s) || 0));
    if (v <= 0) return 0;
    return Math.round(Math.pow(10, (v / 100) * FOLLOWERS_MAX_EXP));
  }

  function setSegmented(group, value) {
    Array.from(group.querySelectorAll('button')).forEach((b) => {
      b.classList.toggle('is-on', b.dataset.val === value);
    });
  }
  function getSegmented(group) {
    const on = group.querySelector('button.is-on');
    return on ? on.dataset.val : 'medium';
  }

  // Citește profilul curent și poziționează controalele pe valorile lui.
  function refresh() {
    if (!el.followers) return;
    baseline = sb.getData ? sb.getData() : null;
    if (!baseline) return;
    baseScore = sb.score(baseline, sb.categoryKey(baseline.sport));

    el.followers.value = String(followersToSlider(baseline.followers));
    setSegmented(el.frequency, baseline.frequency);
    el.level.value = baseline.level;
    el.audience.value = baseline.audience;
    el.offer.checked = baseline.revenue === 'mixed';
    el.results.checked = false;
    recompute();
  }

  // Construiește datele simulate din baseline + valorile controalelor.
  function simData() {
    const followers = sliderToFollowers(el.followers.value);
    const frequency = getSegmented(el.frequency);
    const level = el.level.value;
    const audience = el.audience.value;
    const offer = el.offer.checked;
    const results = el.results.checked;
    return {
      ...baseline,
      followers,
      frequency,
      level,
      audience,
      revenue: offer ? 'mixed' : baseline.revenue,
      assets: offer ? `${baseline.assets}. ${STRONG_ASSETS}` : baseline.assets,
      results: results ? `${baseline.results}. ${STRONG_RESULTS}` : baseline.results,
      _flags: { offer, results }
    };
  }

  function deltaChip(delta, unitPos, unitNeg) {
    if (delta > 0) return { cls: 'up', text: `+${delta}${unitPos || ''}` };
    if (delta < 0) return { cls: 'down', text: `${delta}${unitNeg || unitPos || ''}` };
    return { cls: 'flat', text: '±0' };
  }

  function mid(v) { return v ? Math.round((v.low + v.high) / 2) : 0; }

  function buildPlan(sim) {
    const steps = [];
    const targetF = sim.followers;
    const baseF = baseline.followers || 0;
    // prag relativ: robust la rotunjirea slider-ului logaritmic (nu declanșa
    // un pas fals când profilul e neschimbat)
    if (targetF > baseF * 1.10 + 100) {
      const need = targetF - baseF;
      const perMonth = Math.max(1, Math.round(need / 3));
      steps.push(`Crește audiența cu ~${sb.format.number(need)} urmăritori (aprox. ${sb.format.number(perMonth)}/lună): conținut constant, colaborări locale și cross-posting pe toate platformele.`);
    }
    const bf = FREQ_ORDER.indexOf(baseline.frequency);
    const sf = FREQ_ORDER.indexOf(sim.frequency);
    if (sf > bf) steps.push(`Treci la ${FREQ_LABEL[sim.frequency]} — fixează un calendar editorial și pregătește conținut în avans.`);

    const bl = LEVEL_ORDER.indexOf(baseline.level);
    const sl = LEVEL_ORDER.indexOf(sim.level);
    if (sl > bl) steps.push(`Țintește nivelul „${LEVEL_LABEL[sim.level]}": documentează fiecare competiție și progresul spre acest obiectiv.`);

    if ((AUD_RELEVANCE[sim.audience] || 0) > (AUD_RELEVANCE[baseline.audience] || 0)) {
      steps.push(`Reorientează comunicarea spre ${AUD_LABEL[sim.audience]} — o audiență cu valoare mai mare pentru sponsori.`);
    }
    if (sim._flags.offer && baseline.revenue !== 'mixed') {
      steps.push('Construiește o ofertă clară pentru sponsori: pachet cu livrabile explicite (logo, postări, video, apariții, drepturi de imagine).');
    }
    if (sim._flags.results) {
      steps.push('Adună dovezi de credibilitate: clasamente, diplome și 2 testimoniale (antrenor + club).');
    }
    return steps;
  }

  function recompute() {
    if (!baseline) return;
    const sim = simData();
    const sc = sb.score(sim, sb.categoryKey(sim.sport));

    // slider readout
    el.followersOut.textContent = sb.format.number(sim.followers);

    // gauge
    el.arc.style.strokeDashoffset = String(C * (1 - sc.total / 100));
    el.ghost.style.strokeDashoffset = String(C * (1 - baseScore.total / 100));
    el.score.textContent = sc.total;

    const dScore = deltaChip(sc.total - baseScore.total, '');
    el.scoreDelta.textContent = dScore.text;
    el.scoreDelta.className = `sim-delta ${dScore.cls}`;

    // valoare
    el.value.textContent = `${sb.format.lei(sc.value.low)} – ${sb.format.lei(sc.value.high)}`;
    const dVal = mid(sc.value) - mid(baseScore.value);
    const dv = deltaChip(dVal, ' lei/lună');
    el.valueDelta.textContent = `${dv.text} față de profilul curent · reach ~${sb.format.number(sc.value.reach)}`;
    el.valueDelta.className = `sim-value-delta ${dv.cls}`;

    // sub-scoruri: ghost (curent) + fill (simulat)
    el.subs.innerHTML = sc.breakdown.map((b) => {
      const base = baseScore.breakdown.find((x) => x.key === b.key) || { value: 0 };
      return `
        <div class="sim-sub">
          <div class="sim-sub-top"><span>${b.label}</span><strong>${base.value} → ${b.value}</strong></div>
          <div class="sim-meter">
            <span class="sim-meter-ghost" style="width:${base.value}%"></span>
            <span class="sim-meter-fill" style="width:${b.value}%"></span>
          </div>
        </div>`;
    }).join('');

    // plan 90 zile
    const steps = buildPlan(sim);
    el.plan.innerHTML = steps.length
      ? steps.map((s) => `<li>${s}</li>`).join('')
      : '<li>Ești deja la parametrii simulați. Mărește o valoare pentru a vedea drumul de creștere.</li>';
  }

  function applyToProfile() {
    if (!baseline) return;
    const sim = simData();
    sb.applyProfilePatch({
      followers: sim.followers,
      frequency: sim.frequency,
      level: sim.level,
      audience: sim.audience,
      revenue: sim.revenue,
      assets: sim.assets,
      results: sim.results
    });
    sb.showToast('Parametrii simulați au fost aplicați în profil.');
    // applyProfilePatch → generate() → refresh() readuce controalele pe noul profil
  }

  function bind() {
    el = {
      followers: $('simFollowers'), followersOut: $('simFollowersOut'),
      frequency: $('simFrequency'), level: $('simLevel'), audience: $('simAudience'),
      offer: $('simOffer'), results: $('simResults'),
      reset: $('simReset'), apply: $('simApply'),
      arc: $('simArc'), ghost: $('simGhost'), score: $('simScore'), scoreDelta: $('simScoreDelta'),
      value: $('simValue'), valueDelta: $('simValueDelta'), subs: $('simSubs'), plan: $('simPlan')
    };
    if (!el.followers) return; // panoul nu există pe această pagină

    el.followers.addEventListener('input', recompute);
    el.level.addEventListener('change', recompute);
    el.audience.addEventListener('change', recompute);
    el.offer.addEventListener('change', recompute);
    el.results.addEventListener('change', recompute);
    Array.from(el.frequency.querySelectorAll('button')).forEach((b) => {
      b.addEventListener('click', () => { setSegmented(el.frequency, b.dataset.val); recompute(); });
    });
    el.reset.addEventListener('click', refresh);
    el.apply.addEventListener('click', applyToProfile);

    // reîncarcă baseline când intri pe pagina Raport
    document.addEventListener('sbai:viewchange', (e) => {
      if (e.detail && e.detail.view === 'raport') refresh();
    });
  }

  function init() {
    bind();
    refresh();
  }

  sb.sim = { refresh, recompute };

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', init);
  } else {
    init();
  }
})();
