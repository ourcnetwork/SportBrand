'use strict';

(function clubReport() {
  const sb = window.SBAI;
  const app = document.getElementById('crApp');

  function esc(str) {
    return String(str == null ? '' : str).replace(/[&<>"']/g, (c) => ({
      '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;'
    }[c]));
  }

  // Preferă datele din link (funcționează indiferent de partiționarea
  // localStorage între pagini file://); cade pe rosterul local dacă pagina
  // e deschisă direct, fără link.
  function getEntries() {
    const m = /r=([^&]+)/.exec(window.location.hash || '');
    if (m) {
      try {
        const parsed = JSON.parse(sb.share.decodeString(m[1]));
        if (Array.isArray(parsed)) return parsed;
      } catch (_) { /* cade pe roster local */ }
    }
    return sb.roster.list();
  }

  function computeStats(entries) {
    if (!entries.length) return null;
    const avgScore = Math.round(entries.reduce((s, e) => s + e.sc.total, 0) / entries.length);
    const weakCount = {};
    entries.forEach((e) => {
      const label = e.sc.weakest ? e.sc.weakest.label : null;
      if (label) weakCount[label] = (weakCount[label] || 0) + 1;
    });
    const weakestSorted = Object.entries(weakCount).sort((a, b) => b[1] - a[1]);
    const valueLow = entries.reduce((s, e) => s + (e.sc.value ? e.sc.value.low : 0), 0);
    const valueHigh = entries.reduce((s, e) => s + (e.sc.value ? e.sc.value.high : 0), 0);
    return {
      count: entries.length,
      avgScore,
      weakestLabel: weakestSorted.length ? weakestSorted[0][0] : '—',
      valueLow,
      valueHigh
    };
  }

  function render(entries) {
    if (!entries || !entries.length) {
      app.innerHTML = `
        <header class="cr-header">
          <div class="cr-brand"><span class="cr-mark">SB</span><div><strong>SportBrand AI</strong><small>Raport de club</small></div></div>
        </header>
        <p class="cr-empty">Rosterul e gol. Adaugă sportivi din pagina principală (secțiunea „Roster de club") și deschide din nou raportul.</p>`;
      return;
    }

    const stats = computeStats(entries);
    const sorted = [...entries].sort((a, b) => b.sc.total - a.sc.total);
    const payloads = sorted.map((e) => sb.share.buildPayload(e.data, e.sc));

    const rows = payloads.map((p, i) => `
      <tr>
        <td class="rank">#${i + 1}</td>
        <td>${esc(p.name)}</td>
        <td>${esc(p.sportLabel)}</td>
        <td>${esc(p.level)}</td>
        <td class="score">${p.score}</td>
        <td>${esc(p.valueLine || '—')}</td>
        <td>${esc(p.weakestLabel || '—')}</td>
      </tr>`).join('');

    app.innerHTML = `
      <header class="cr-header">
        <div class="cr-brand"><span class="cr-mark">SB</span><div><strong>SportBrand AI</strong><small>Generat ${esc(sb.format.dateLong(new Date()))}</small></div></div>
        <div class="cr-actions">
          <button class="cr-btn ghost" id="crBack" type="button">Înapoi</button>
          <button class="cr-btn" id="crPrint" type="button">Exportă PDF (Print)</button>
        </div>
      </header>
      <h1>Raport de club</h1>
      <p class="cr-sub">Portofoliu de ${stats.count} sportivi · sortat după scor comercial descrescător.</p>

      <div class="cr-stats">
        <article><span>Sportivi în roster</span><strong>${stats.count}</strong></article>
        <article><span>Scor mediu</span><strong>${stats.avgScore}/100</strong></article>
        <article><span>Valoare lunară estimată (total roster)</span><strong>${esc(sb.format.lei(stats.valueLow))}–${esc(sb.format.lei(stats.valueHigh))}</strong></article>
        <article><span>Cea mai frecventă slăbiciune</span><strong style="font-size:.95rem">${esc(stats.weakestLabel)}</strong></article>
      </div>

      <div class="cr-table-wrap">
        <table>
          <thead><tr><th>#</th><th>Sportiv</th><th>Sport</th><th>Nivel</th><th>Scor</th><th>Valoare/lună</th><th>De lucrat</th></tr></thead>
          <tbody>${rows}</tbody>
        </table>
      </div>

      <p class="cr-footer">Generat cu SportBrand AI · valorile sunt orientative, nu reprezintă o garanție contractuală.</p>
    `;

    document.getElementById('crPrint').addEventListener('click', () => window.print());
    document.getElementById('crBack').addEventListener('click', () => { window.location.href = 'index.html'; });
  }

  render(getEntries());
})();
