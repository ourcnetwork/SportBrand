'use strict';

/* Mod Club / Academie.
   Un antrenor/manager salvează mai mulți sportivi în roster (localStorage),
   vede scoruri comparate și poate exporta în lot pagini live + un portofoliu
   de club. NOTĂ ONESTĂ: rosterul stă doar în acest browser — nu se
   sincronizează între dispozitive. Export/Import JSON e plasa de siguranță. */

window.SBAI = window.SBAI || {};

(function roster() {
  const sb = window.SBAI;
  const KEY = 'roster_v1';

  function makeId(data) {
    return `${sb.slug(data.sport) || 'sport'}__${sb.slug(data.name) || 'atlet'}`;
  }

  function list() {
    const raw = sb.storage.getJSON(KEY);
    return Array.isArray(raw) ? raw : [];
  }

  function persist(entries) {
    return sb.storage.setJSON(KEY, entries);
  }

  function save(data, sc) {
    const entries = list();
    const id = makeId(data);
    const entry = {
      id,
      savedAt: new Date().toISOString(),
      data: { ...data },
      sc: { total: sc.total, breakdown: sc.breakdown, weakest: sc.weakest, value: sc.value }
    };
    const idx = entries.findIndex((e) => e.id === id);
    if (idx >= 0) entries[idx] = entry; else entries.push(entry);
    persist(entries);
    return id;
  }

  function remove(id) {
    persist(list().filter((e) => e.id !== id));
  }

  function clear() {
    sb.storage.remove(KEY);
  }

  function get(id) {
    return list().find((e) => e.id === id) || null;
  }

  // Reutilizează formatarea din share.js — un entry de roster e doar
  // { data, sc } persistate, exact ce cere buildPayload.
  function payloadFor(entry) {
    return sb.share.buildPayload(entry.data, entry.sc);
  }

  function stats() {
    const entries = list();
    if (!entries.length) return { count: 0 };

    const avgScore = Math.round(entries.reduce((s, e) => s + e.sc.total, 0) / entries.length);

    const weakCount = {};
    entries.forEach((e) => {
      const label = e.sc.weakest ? e.sc.weakest.label : null;
      if (!label) return;
      weakCount[label] = (weakCount[label] || 0) + 1;
    });
    const weakestEntries = Object.entries(weakCount).sort((a, b) => b[1] - a[1]);
    const weakestAggLabel = weakestEntries.length ? weakestEntries[0][0] : '';

    const top = [...entries].sort((a, b) => b.sc.total - a.sc.total).slice(0, 3);

    const totalValueLow = entries.reduce((s, e) => s + (e.sc.value ? e.sc.value.low : 0), 0);
    const totalValueHigh = entries.reduce((s, e) => s + (e.sc.value ? e.sc.value.high : 0), 0);

    return { count: entries.length, avgScore, weakestAggLabel, top, totalValueLow, totalValueHigh };
  }

  function exportJSON() {
    return JSON.stringify({ v: 1, exportedAt: new Date().toISOString(), entries: list() }, null, 2);
  }

  function importJSON(str, mode) {
    let parsed;
    try { parsed = JSON.parse(str); } catch (_) { return { ok: false, error: 'Fișier JSON invalid.' }; }
    const incoming = Array.isArray(parsed) ? parsed : (parsed && Array.isArray(parsed.entries) ? parsed.entries : null);
    if (!incoming) return { ok: false, error: 'Formatul fișierului nu e recunoscut.' };

    let entries = mode === 'replace' ? [] : list();
    let count = 0;
    incoming.forEach((e) => {
      if (!e || !e.data || !e.sc) return;
      const id = e.id || makeId(e.data);
      const clean = { id, savedAt: e.savedAt || new Date().toISOString(), data: e.data, sc: e.sc };
      const idx = entries.findIndex((x) => x.id === id);
      if (idx >= 0) entries[idx] = clean; else entries.push(clean);
      count += 1;
    });
    persist(entries);
    return { ok: true, count };
  }

  // Linkul poartă rosterul direct în hash (ca la Pagina Live), ca raportul
  // de club să funcționeze indiferent de partiționarea localStorage între
  // pagini file:// — nu depinde de storage comun între index.html și
  // club-report.html.
  function buildClubReportLink() {
    const entries = list();
    const encoded = sb.share.encodeString(JSON.stringify(entries));
    const base = window.location.href.split('#')[0].replace(/[^/]*$/, '');
    return `${base}club-report.html#r=${encoded}`;
  }

  sb.roster = { list, save, remove, clear, get, payloadFor, stats, exportJSON, importJSON, makeId, buildClubReportLink };
})();
