'use strict';

/* Router simplu de „pagini" (views) pentru aplicația single-page.
   Fiecare view e o secțiune .view[data-view]; doar una e activă la un moment
   dat și intră glisând din dreapta. Navigația se face din meniul lateral
   (data-view) sau din butoanele contextuale din pagini (data-go). */

window.SBAI = window.SBAI || {};

(function views() {
  const sb = window.SBAI;
  const FUNNEL = ['profil', 'raport', 'live', 'roster', 'premium'];
  const DOCS = ['ghid', 'termeni', 'confidentialitate', 'cookies'];
  const ALL = FUNNEL.concat(DOCS);
  const DEFAULT = 'profil';

  let current = null;

  function allViews() {
    return Array.from(document.querySelectorAll('.view[data-view]'));
  }

  function navItems() {
    return Array.from(document.querySelectorAll('.nav-item[data-view]'));
  }

  function isValid(name) {
    return ALL.indexOf(name) !== -1;
  }

  function setNavActive(name) {
    navItems().forEach((btn) => {
      const on = btn.dataset.view === name;
      btn.classList.toggle('is-active', on);
      if (on) btn.setAttribute('aria-current', 'page');
      else btn.removeAttribute('aria-current');
    });
  }

  function show(name, opts) {
    const options = opts || {};
    const target = isValid(name) ? name : DEFAULT;
    if (target === current) {
      // reafișează animația doar dacă e o navigare explicită repetată? Nu — ieșim.
      return;
    }

    const views = allViews();
    views.forEach((v) => {
      const on = v.dataset.view === target;
      v.classList.toggle('is-active', on);
      if (on) {
        // re-trigger animația de intrare din dreapta
        v.classList.remove('slide-in');
        // reflow forțat ca animația să repornească la fiecare navigare
        void v.offsetWidth;
        v.classList.add('slide-in');
      }
    });

    setNavActive(target);
    current = target;

    // sincronizează hash-ul fără să declanșeze scroll brusc
    if (!options.skipHash) {
      try {
        const newHash = `#${target}`;
        if (window.location.hash !== newHash) {
          history.replaceState(null, '', newHash);
        }
      } catch (_) { /* file:// poate refuza replaceState */ }
    }

    // adu conținutul în vizor (util pe mobil, unde meniul e sus)
    if (!options.noScroll) {
      const main = document.getElementById('top');
      if (main && typeof main.scrollIntoView === 'function') {
        main.scrollIntoView({ behavior: options.instant ? 'auto' : 'smooth', block: 'start' });
      } else {
        window.scrollTo({ top: 0, behavior: options.instant ? 'auto' : 'smooth' });
      }
    }

    document.dispatchEvent(new CustomEvent('sbai:viewchange', { detail: { view: target } }));
  }

  function go(name) {
    show(name, {});
  }

  function next() {
    const i = FUNNEL.indexOf(current);
    if (i >= 0 && i < FUNNEL.length - 1) go(FUNNEL[i + 1]);
  }

  function prev() {
    const i = FUNNEL.indexOf(current);
    if (i > 0) go(FUNNEL[i - 1]);
  }

  function bind() {
    // meniu lateral
    navItems().forEach((btn) => {
      btn.addEventListener('click', () => go(btn.dataset.view));
    });
    // butoane contextuale din pagini + brand-ul din sidebar
    document.querySelectorAll('[data-go]').forEach((el) => {
      el.addEventListener('click', (e) => {
        if (el.tagName === 'A') e.preventDefault();
        go(el.dataset.go);
      });
    });
    // navigare browser înainte/înapoi prin hash
    window.addEventListener('hashchange', () => {
      const name = (window.location.hash || '').replace('#', '');
      if (isValid(name)) show(name, { skipHash: true });
    });
  }

  function init() {
    bind();
    const initial = (window.location.hash || '').replace('#', '');
    show(isValid(initial) ? initial : DEFAULT, { skipHash: isValid(initial), instant: true, noScroll: true });
  }

  sb.views = { go, next, prev, show, get current() { return current; }, FUNNEL, ALL };

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', init);
  } else {
    init();
  }
})();
