'use strict';

/* Motor de scor comercial.
   Înlocuiește heuristica aditivă cu 5 sub-scoruri ponderate, transparente,
   plus o estimare de valoare pentru sponsori. Fiecare sub-scor e 0–100;
   scorul general e media ponderată. Din cel mai slab sub-scor derivăm
   „următorul pas prioritar". */

window.SBAI = window.SBAI || {};

(function scoring() {
  const clamp = (n, min = 0, max = 100) => Math.max(min, Math.min(max, n));

  const levelWeight = {
    junior: 30, amator: 42, 'semi-pro': 60, profesionist: 78, 'lot-national': 90, olimpic: 100
  };

  const frequencyWeight = { low: 40, medium: 70, high: 100 };

  const audienceRelevance = {
    corporate: 100, performanta: 90, local: 80, juniori: 72, lifestyle: 66
  };

  // Scor logaritmic pentru urmăritori: recompensează creșterea reală,
  // fără să sară brusc la praguri arbitrare.
  function followersScore(f) {
    const n = Math.max(0, Number(f) || 0);
    if (n <= 0) return 8;
    // ~0 la 100, ~100 la 100.000+
    const s = (Math.log10(n) / Math.log10(100000)) * 100;
    return clamp(Math.round(s));
  }

  function textScore(text, floor = 12, per = 2.2, cap = 100) {
    const len = String(text || '').trim().length;
    return clamp(Math.round(floor + len / per), 0, cap);
  }

  function subScores(data) {
    const rezultate = clamp(Math.round(
      0.6 * textScore(data.results, 10, 1.8) + 0.4 * (levelWeight[data.level] || 40)
    ));
    const audienta = clamp(Math.round(
      0.7 * followersScore(data.followers) + 0.3 * (audienceRelevance[data.audience] || 70)
    ));
    const nivel = levelWeight[data.level] || 40;
    const consistenta = frequencyWeight[data.frequency] || 55;
    const oferta = clamp(Math.round(
      0.7 * textScore(data.assets, 14, 2.0) + 0.3 * (data.revenue === 'mixed' ? 90 : 70)
    ));

    return [
      { key: 'rezultate', label: 'Rezultate & credibilitate', value: rezultate, weight: 0.30 },
      { key: 'audienta', label: 'Audiență & reach', value: audienta, weight: 0.24 },
      { key: 'nivel', label: 'Nivel competițional', value: nivel, weight: 0.18 },
      { key: 'consistenta', label: 'Consistență conținut', value: consistenta, weight: 0.14 },
      { key: 'oferta', label: 'Ofertă pentru sponsori', value: oferta, weight: 0.14 }
    ];
  }

  function overall(breakdown) {
    const total = breakdown.reduce((s, b) => s + b.value * b.weight, 0);
    return clamp(Math.round(total));
  }

  function message(score) {
    if (score >= 82) return 'Profil comercial puternic. Treci direct la media kit, ofertă și negociere.';
    if (score >= 65) return 'Profil bun. Clarifică pachetele și crește frecvența video.';
    if (score >= 45) return 'Profil promițător. Ai nevoie de storytelling, rezultate vizibile și ofertă simplă.';
    return 'Profil la început. Construiește bazele: poveste, imagini bune, ritm de postare și contact clar.';
  }

  // Următorul pas prioritar = derivat din cel mai slab sub-scor.
  const nextActionByWeakest = {
    rezultate: 'Adaugă rezultate concrete și cere 2 testimoniale (antrenor / club).',
    audienta: 'Crește reach-ul: postează constant și colaborează local pentru distribuție.',
    nivel: 'Documentează progresul competițional — fiecare concurs devine conținut.',
    consistenta: 'Fixează un ritm: minimum 3 postări pe săptămână, planificate.',
    oferta: 'Definește clar ce primește sponsorul (logo, postări, video, apariții).'
  };

  function weakest(breakdown) {
    return breakdown.reduce((min, b) => (b.value < min.value ? b : min), breakdown[0]);
  }

  // Estimare de valoare comercială lunară (orientativă) pentru un sponsor.
  // Bazată pe reach estimat, nivel, categorie de sport și scor.
  function estimateValue(data, breakdown, score, category) {
    const followers = Math.max(0, Number(data.followers) || 0);
    // Reach lunar estimat: audiență proprie + amplificare (2.2x prin distribuție).
    const reach = Math.round(followers * 2.2 + 400);
    const levelMult = 0.7 + (levelWeight[data.level] || 40) / 100; // 1.0 – 1.7
    const catMult = (window.SBAI.config.categoryValue[category] || 1);
    const scoreMult = 0.6 + score / 125; // 0.6 – 1.4

    // CPM orientativ pentru sponsorizare sportivă locală: 25–55 lei / 1000 afișări.
    const base = (reach / 1000);
    let low = Math.round(base * 25 * levelMult * catMult * scoreMult + 120);
    let high = Math.round(base * 55 * levelMult * catMult * scoreMult + 350);

    // Rotunjire „prietenoasă" la zeci.
    low = Math.max(150, Math.round(low / 10) * 10);
    high = Math.max(low + 200, Math.round(high / 10) * 10);

    return { reach, low, high };
  }

  window.SBAI.score = function score(data, category) {
    const breakdown = subScores(data);
    const total = overall(breakdown);
    const weak = weakest(breakdown);
    return {
      total,
      breakdown,
      message: message(total),
      weakest: weak,
      nextAction: nextActionByWeakest[weak.key] || 'Completează profilul pentru recomandare.',
      value: estimateValue(data, breakdown, total, category)
    };
  };
})();
