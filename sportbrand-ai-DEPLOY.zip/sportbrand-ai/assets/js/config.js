'use strict';

/* Configurare centrală. Un singur loc pentru prețuri, coduri și date de brand.
   Modifici aici, se propagă în toată aplicația. */

window.SBAI = window.SBAI || {};

window.SBAI.config = {
  brand: {
    name: 'SportBrand AI',
    by: 'by Liga Sportivilor',
    mark: 'SB',
    // Canalul operatorului: unde ajung comenzile (email + WhatsApp).
    // Lasă gol ca să folosești mailto fără destinatar prestabilit.
    operatorEmail: '',
    operatorWhatsApp: '' // format internațional fără +, ex: 407xxxxxxxx
  },

  // Colectare lead-uri în Google Sheets (opțional).
  // Aplicația e statică, deci „serverul" e un Google Apps Script pe care îl
  // publici tu (vezi google-apps-script.gs + secțiunea din README).
  // Lasă gol ca să dezactivezi complet colectarea (aplicația merge la fel).
  collect: {
    // URL-ul Web App generat după deploy-ul Apps Script (începe cu
    // https://script.google.com/macros/s/.../exec)
    // ACELAȘI endpoint e folosit și de funcțiile „backend" de mai jos.
    sheetsEndpoint: '',
    // Trimite automat și la generarea raportului (nu doar la comandă)?
    // false = trimite doar comenzile (recomandat, evită spam-ul).
    sendOnGenerate: false
  },

  // Funcții „backend" pe același Apps Script. Toate se activează DOAR dacă
  // collect.sheetsEndpoint de mai sus e completat; altfel aplicația rămâne
  // 100% statică (fallback automat).
  backend: {
    serverCodes: true, // validează codurile premium pe server (fila „Codes")
    shortLinks: true,  // Pagina Live folosește linkuri scurte (brand.html?p=ID)
    analytics: true,   // numără vizualizări + click-uri pe Pagina Live
    ai: true           // generare AI reală (cere cheie Gemini în Script Properties)
  },

  // Cod demo pentru testare rapidă. În producție e doar backup;
  // fluxul real folosește coduri unice per comandă (vezi premium.js).
  premiumDemoCode: 'LS-PREMIUM-2026',
  // Sarea folosită la generarea codurilor unice. Schimb-o pentru un deploy nou.
  codeSalt: 'liga-sportivilor-2026',

  prices: {
    strategy: { id: 'strategy', label: 'Strategie PDF', price: '99 lei', badge: 'Start' },
    mediaKit: { id: 'mediaKit', label: 'Media Kit + Sponsori', price: '399 lei', badge: 'Recomandat', featured: true },
    club: { id: 'club', label: 'Club / Academie', price: '499–999 lei/lună', badge: 'Club' }
  },

  // Multiplicatori de valoare comercială per categorie de sport (orientativ).
  // Folosiți în estimarea valorii pentru sponsori.
  categoryValue: {
    team: 1.15, aesthetic: 1.20, combat: 1.05, racket: 1.10,
    endurance: 1.00, precision: 0.95, strength: 0.95, outdoor: 1.05
  }
};
