'use strict';

/* Generatoare de conținut. Toată logica de „ce text producem" stă aici,
   separat de wiring-ul DOM (app.js) și de scor (scoring.js). */

window.SBAI = window.SBAI || {};

(function generators() {
  const sb = window.SBAI;

  sb.label = (value) => sb.labels[value] || value;
  sb.slug = (text) => String(text || '').toLowerCase().normalize('NFD')
    .replace(/[\u0300-\u036f]/g, '').replace(/[^a-z0-9]+/g, '');

  sb.findProfile = (sport) =>
    Object.values(sb.sportProfiles).find((p) => p.sports.includes(sport)) || sb.sportProfiles.endurance;

  sb.categoryKey = (sport) => {
    const entry = Object.entries(sb.sportProfiles).find(([, p]) => p.sports.includes(sport));
    return entry ? entry[0] : 'endurance';
  };

  sb.goalText = (goal) => ({
    sponsori: 'atragerea de sponsori prin credibilitate, rezultate, audiență și beneficii clare',
    vizibilitate: 'creșterea notorietății prin conținut constant, poveste personală și distribuție locală',
    vanzari: 'transformarea imaginii sportive în produse, servicii, evenimente și oferte vandabile',
    comunitate: 'construirea unei comunități active care urmărește progresul și susține parcursul sportiv',
    recrutare: 'prezentarea sportivului ca profil relevant pentru cluburi, academii și scouteri',
    fundraising: 'susținerea financiară transparentă pentru competiții, deplasări, echipament și pregătire'
  }[goal] || goal);

  const audienceText = (audience) => ({
    local: 'comunitatea locală, părinții, antreprenorii și presa din zonă',
    juniori: 'copii, juniori, părinți și cluburi care caută modele sportive sănătoase',
    performanta: 'sportivi, antrenori, cluburi și oameni interesați de performanță reală',
    lifestyle: 'public interesat de sănătate, disciplină, transformare și stil de viață activ',
    corporate: 'companii care vor asociere cu disciplină, performanță, leadership și reziliență'
  }[audience] || audience);
  sb.audienceText = audienceText;

  const freq = (f) => (f === 'high' ? '5+' : f === 'medium' ? '3-4' : '1-2');
  const valueLine = (v) => v
    ? `Valoare comercială estimată pentru un sponsor: ${sb.format.lei(v.low)}–${sb.format.lei(v.high)}/lună (reach lunar estimat ~${sb.format.number(v.reach)}). Cifre orientative, de ajustat după rezultate reale.`
    : '';

  sb.gen = {
    freeStrategy(data) {
      const p = sb.findProfile(data.sport);
      return `RAPORT BASIC SPORTBRAND AI\n\nSportiv / club: ${data.name}\nSport: ${sb.label(data.sport)}\nCategorie: ${p.label}\nNivel: ${data.level}\nOraș / zonă: ${data.city}\n\n1. POZIȚIONARE RAPIDĂ\n${data.name} trebuie poziționat ca profil ${data.tone}, construit pe ${p.angle}. Obiectivul principal este ${sb.goalText(data.goal)}.\n\n2. PRIORITATE DE PROMOVARE\nÎncepe cu un profil social clar, 3 postări pe săptămână și o poveste simplă: cine ești, ce rezultate ai și de ce meriți susținere.\n\n3. UPGRADE PREMIUM\nPentru calendar 30 zile, media kit, pachete sponsor, outreach și PDF premium, activează accesul premium.`;
    },

    strategy(data, sc) {
      const p = sb.findProfile(data.sport);
      return `STRATEGIE SPORTBRAND AI\n\nSportiv / club: ${data.name}\nSport: ${sb.label(data.sport)}\nCategorie: ${p.label}\nNivel: ${data.level}\nOraș / zonă: ${data.city}\nPublic principal: ${audienceText(data.audience)}\nRezultate: ${data.results}\n\n${valueLine(sc && sc.value)}\n\n1. POZIȚIONARE\n${data.name} trebuie poziționat ca profil ${data.tone}, construit pe ${p.angle}. Obiectivul principal este ${sb.goalText(data.goal)}.\n\n2. PROMISIUNE DE BRAND\nFormula recomandată: „${data.name} — performanță, disciplină și progres în ${sb.label(data.sport)}." Mesajul trebuie repetat în bio, postări, media kit și propunerile către sponsori.\n\n3. STRATEGIE DE PROMOVARE\n- Publică minimum ${freq(data.frequency)} materiale pe săptămână.\n- Mix recomandat: 40% antrenament, 25% rezultate, 20% poveste personală, 15% conținut sponsor-friendly.\n- Format principal: video scurt cu execuție, progres, detaliu tehnic, reacție și concluzie.\n- Transformă fiecare competiție într-o campanie: înainte, în timpul, după, lecții învățate.\n\n4. PRIORITATE IMEDIATĂ\n${sc ? sc.nextAction : 'Completează profilul pentru recomandare.'}\n\n5. MONETIZARE\nDirecții recomandate: ${p.products}. Model ales: ${data.revenue}. Prima ofertă trebuie să fie simplă, explicabilă în 10 secunde și legată direct de credibilitatea sportivă.\n\n6. SPONSORI POTRIVIȚI\nCategorii recomandate: ${p.sponsors}. Începe cu 30 de firme locale din ${data.city}, apoi construiește o listă națională.\n\n7. CE VINDE SPORTIVUL\nSportivul nu vinde doar postări. Vinde disciplină, asociere pozitivă, încredere, poveste locală, conținut, apariții și acces la o comunitate relevantă.`;
    },

    brand(data) {
      const p = sb.findProfile(data.sport);
      return `BRAND PERSONAL\n\nArhetip recomandat: sportiv ${data.tone}, orientat spre ${p.angle}.\n\nBio scurt:\n${data.name} · ${sb.label(data.sport)} · ${data.city}\nPerformanță, disciplină și progres vizibil. Deschis pentru parteneriate și sponsorizări.\n\nMesaj central:\n„Susținerea unui sportiv înseamnă asociere cu muncă, caracter și performanță reală."\n\nPiloni de comunicare:\n1. Dovadă — rezultate, competiții, antrenamente.\n2. Poveste — sacrificiu, disciplină, obstacole, familie, club.\n3. Comunitate — oraș, copii, părinți, susținători.\n4. Sponsor-friendly — ce poate primi partenerul comercial.\n\nTon vizual:\nCadre curate, contrast puternic, sportiv în acțiune, detalii cu echipament, expresie concentrată, fundal real din sport.`;
    },

    content(data) {
      const p = sb.findProfile(data.sport);
      const ideas = p.content.map((item, i) =>
        `${i + 1}. Reel: ${item}\n   Hook: „În ${sb.label(data.sport)}, diferența se vede în detalii."\n   Cadru: 3 secunde impact, 7 secunde execuție, 3 secunde concluzie.`).join('\n\n');
      return `PLAN DE CONȚINUT\n\n${ideas}\n\n4. Postare rezultat\nText: „Fiecare rezultat are în spate ore pe care publicul nu le vede. Următorul obiectiv este mai sus."\nInclude: rezultat, competiție, mulțumiri, obiectiv următor, invitație pentru sponsori.\n\n5. Postare sponsor-friendly\nText: „Caut parteneri care cred în performanță, disciplină și reprezentare locală. Ofer vizibilitate, conținut și asociere cu un parcurs sportiv real."\n\nHashtaguri:\n#sportiv #performanta #sponsorizare #sportromanesc #${sb.slug(sb.label(data.sport))} #${sb.slug(data.city)} #antrenament #campion #disciplina`;
    },

    freeContent(data) {
      const p = sb.findProfile(data.sport);
      return `IDEI BASIC DE CONȚINUT\n\n1. Reel: ${p.content[0]}\nHook: „În ${sb.label(data.sport)}, progresul se vede în detalii."\n\n2. Postare rezultat\nPrezintă rezultatul, competiția, lecția învățată și următorul obiectiv.\n\n3. Postare de credibilitate\nArată o parte din pregătirea pe care publicul nu o vede: disciplină, rutină, sacrificiu.\n\nHashtaguri basic:\n#sportiv #performanta #sportromanesc #${sb.slug(sb.label(data.sport))} #${sb.slug(data.city)}`;
    },

    calendar(data) {
      return `CALENDAR 30 ZILE\n\nSăptămâna 1 — Bază de brand\n- Ziua 1: actualizează bio, poză profil, rezultate și link de contact.\n- Ziua 2: postează povestea sportivă în format scurt.\n- Ziua 3: filmează 5 cadre de antrenament.\n- Ziua 4: publică un Reel tehnic.\n- Ziua 5: creează lista cu 30 de sponsori locali.\n\nSăptămâna 2 — Dovadă și credibilitate\n- Publică 2 Reels și 1 postare cu rezultate.\n- Cere 2 testimoniale de la antrenor, club sau colegi.\n- Pregătește media kit de o pagină.\n\nSăptămâna 3 — Ofertă comercială\n- Publică o postare sponsor-friendly.\n- Trimite 10 mesaje personalizate către firme.\n- Testează o ofertă: ${data.revenue}.\n\nSăptămâna 4 — Conversie\n- Trimite încă 20 de mesaje către sponsori.\n- Programează minimum 3 discuții.\n- Publică un recap cu progresul lunii.\n- Ajustează oferta pe baza răspunsurilor primite.`;
    },

    mediaKit(data, sc) {
      const p = sb.findProfile(data.sport);
      return `MEDIA KIT SPORTIV\n\nNume: ${data.name}\nSport: ${sb.label(data.sport)}\nCategorie: ${p.label}\nOraș: ${data.city}\nNivel: ${data.level}\nUrmăritori social media: ${sb.format.number(data.followers || 0)}\n${sc && sc.value ? `Reach lunar estimat: ~${sb.format.number(sc.value.reach)}\nValoare orientativă parteneriat: ${sb.format.lei(sc.value.low)}–${sb.format.lei(sc.value.high)}/lună` : ''}\n\nBio comercială:\n${data.name} este un profil sportiv construit în jurul performanței, disciplinei și progresului în ${sb.label(data.sport)}. Rezultate relevante: ${data.results}.\n\nPublic relevant:\n${audienceText(data.audience)}.\n\nCe poate primi sponsorul:\n${data.assets}.\n\nCategorii de sponsori potriviți:\n${p.sponsors}.\n\nCTA pentru sponsori:\n„Vă invit să deveniți partener în dezvoltarea unui parcurs sportiv real, cu vizibilitate, conținut autentic și asociere pozitivă în comunitate."`;
    },

    outreach(data, type = 'email') {
      const base = {
        email: `Bună ziua,\n\nSunt ${data.name}, sportiv / reprezentant în ${sb.label(data.sport)}, activ în ${data.city}. Rezultatele mele relevante: ${data.results}.\n\nVă contactez pentru o posibilă colaborare de sponsorizare sau parteneriat de imagine. Pot oferi: ${data.assets}.\n\nCred că asocierea cu un sportiv din ${sb.label(data.sport)} poate aduce brandului dumneavoastră vizibilitate locală, conținut autentic și o imagine legată de disciplină, performanță și progres.\n\nDacă sunteți deschiși, vă pot trimite un media kit de o pagină cu audiența, rezultatele și opțiunile de colaborare.\n\nCu respect,\n${data.name}`,
        whatsapp: `Bună ziua! Sunt ${data.name}, sportiv în ${sb.label(data.sport)}, din ${data.city}. Caut parteneri locali care vor să susțină performanța sportivă. Pot oferi vizibilitate, postări, materiale video și asociere cu rezultatele mele: ${data.results}. Vă pot trimite un media kit scurt?`,
        dm: `Salut! Sunt ${data.name}, sportiv în ${sb.label(data.sport)}. Construiesc un parteneriat cu branduri care susțin performanța locală. Pot oferi conținut, vizibilitate și asociere cu parcursul meu sportiv. Îți pot trimite un media kit?`,
        pitch: `${data.name} · ${sb.label(data.sport)} · ${data.city}. Rezultate: ${data.results}. Caut parteneri care vor vizibilitate autentică prin sport, conținut și asociere cu disciplină/performanță.`
      };
      return base[type] || base.email;
    },

    offer(data) {
      return `PACHETE COMERCIALE RECOMANDATE\n\nBronze — 500 lei/lună\n- 2 postări / lună\n- 2 story-uri\n- mențiune publică sponsor\n- logo în descriere sau material vizual\n\nSilver — 1.500 lei/lună\n- 4 postări / lună\n- 4 story-uri\n- 1 video scurt dedicat\n- logo pe echipament / materiale, unde este posibil\n- raport lunar simplu\n\nGold — 3.000 lei/lună\n- campanie completă lunară\n- 2 video-uri dedicate\n- apariție la eveniment / activare locală\n- drept de folosire a imaginii în campania sponsorului, pe perioadă limitată\n- raport de vizibilitate și rezultate\n\nPrețurile sunt orientative. Pentru ${sb.label(data.sport)}, ajustează prețul în funcție de rezultate, audiență, oraș, calitatea conținutului și exclusivitatea oferită.`;
    }
  };
})();
