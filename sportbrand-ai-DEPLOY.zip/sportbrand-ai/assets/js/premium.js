'use strict';

/* Acces premium.
   NOTĂ HONESTĂ: gating-ul e pe client (localStorage). E potrivit pentru un MVP
   cu plată confirmată manual, DAR nu e securitate reală — oricine cu acces la
   sursă poate debloca. Securizarea corectă cere un backend care emite și
   verifică coduri. Vezi README.

   Îmbunătățire față de codul unic partajat: fiecare comandă primește un cod
   determinist derivat din email+pachet (funcția `codeFor`). Operatorul îl poate
   recalcula după confirmarea plății și îl trimite clientului. Codul demo rămâne
   valabil pentru testare. */

window.SBAI = window.SBAI || {};

(function premium() {
  const cfg = window.SBAI.config;
  const storage = window.SBAI.storage;

  // Hash simplu, determinist (FNV-1a) — suficient pentru coduri MVP, nu criptografic.
  function hash(str) {
    let h = 0x811c9dc5;
    for (let i = 0; i < str.length; i++) {
      h ^= str.charCodeAt(i);
      h = (h + ((h << 1) + (h << 4) + (h << 7) + (h << 8) + (h << 24))) >>> 0;
    }
    return h >>> 0;
  }

  function chunk(num) {
    const alphabet = 'ABCDEFGHJKMNPQRSTUVWXYZ23456789'; // fără caractere ambigue
    let out = '';
    for (let i = 0; i < 4; i++) {
      out += alphabet[num % alphabet.length];
      num = Math.floor(num / alphabet.length) + 7;
    }
    return out;
  }

  // Cod unic pentru o comandă: LS-XXXX-XXXX
  function codeFor(email, packageId) {
    const seed = `${cfg.codeSalt}|${String(email || '').trim().toLowerCase()}|${packageId || ''}`;
    const h1 = hash(seed);
    const h2 = hash(seed + '|check');
    return `LS-${chunk(h1)}-${chunk(h2)}`;
  }

  function isPremium() {
    return storage.get('premium') === 'true';
  }

  function validate(input) {
    const value = String(input || '').trim().toUpperCase();
    if (!value) return false;
    if (value === cfg.premiumDemoCode.toUpperCase()) return true;
    // Recalculează codul pentru ultima comandă salvată.
    const order = storage.getJSON('order_meta');
    if (order && order.email && order.packageId) {
      if (value === codeFor(order.email, order.packageId).toUpperCase()) return true;
    }
    return false;
  }

  // Validare cu backend (fila „Codes"), dacă e configurat. Codul demo rămâne
  // valabil local pentru testare, chiar și cu backend activ. Fallback complet
  // pe validarea locală când nu există backend.
  async function validateAsync(input) {
    const sb = window.SBAI;
    const value = String(input || '').trim();
    if (!value) return false;
    if (value.toUpperCase() === cfg.premiumDemoCode.toUpperCase()) return true;
    if (sb.api && sb.api.flag('serverCodes')) {
      const order = storage.getJSON('order_meta') || {};
      const ok = await sb.api.validateCode(value, order.email || '');
      if (ok) return true;
      // dacă serverul spune nu, mai încearcă și codul local (comandă offline)
      return validate(value);
    }
    return validate(value);
  }

  function lockedHTML(title) {
    const p = cfg.prices;
    return `<div class="locked-output"><div class="lock-icon">🔒</div>` +
      `<strong>${title} este disponibil în PREMIUM.</strong>` +
      `<span>Flux: comandă pachet → confirmare plată manuală → cod premium → raport complet.</span>` +
      `<ul><li>${p.strategy.label} — ${p.strategy.price}</li>` +
      `<li>${p.mediaKit.label} — ${p.mediaKit.price}</li>` +
      `<li>${p.club.label} — ${p.club.price}</li></ul></div>`;
  }

  function setState(active, silent = false) {
    const sb = window.SBAI;
    const on = Boolean(active);
    storage.set('premium', on ? 'true' : 'false');
    document.body.classList.toggle('is-premium', on);
    document.body.classList.toggle('is-free', !on);

    const pairs = {
      premiumStatus: on ? 'Acces PREMIUM activ · raport complet și PDF profesional deblocate.'
        : 'Acces FREE activ · raport basic disponibil.',
      accessLabel: on ? 'PREMIUM' : 'FREE',
      accessText: on ? 'Raport complet, media kit și export PDF active.'
        : 'Raport basic activ. Codul deblochează raportul premium.',
      exportHelp: on ? 'PREMIUM activ: poți copia, salva local și exporta raportul complet ca PDF profesional.'
        : 'FREE: copiezi raportul basic. Introdu codul premium pentru export PDF profesional.',
      pdfPlan: on ? 'PREMIUM' : 'FREE'
    };
    Object.entries(pairs).forEach(([id, value]) => {
      const el = document.getElementById(id);
      if (el) el.textContent = value;
    });

    const printBtn = document.getElementById('printBtn');
    if (printBtn) printBtn.textContent = on ? 'Export PDF premium' : 'PDF premium blocat';

    if (!silent && sb.showToast) sb.showToast(on ? 'Accesul premium a fost activat.' : 'Ai revenit la accesul FREE.');
    if (!silent && sb.regenerateIfReady) sb.regenerateIfReady();
  }

  window.SBAI.premium = { codeFor, isPremium, validate, validateAsync, lockedHTML, setState };
  // Compat cu apeluri vechi din alte module.
  window.SBAI.isPremium = isPremium;
  window.SBAI.premiumLockedHTML = lockedHTML;
  window.SBAI.setPremiumState = setState;
})();
