'use strict';

/* Orchestrare. Leagă UI-ul de servicii, scor și generatoare.
   Fără logică de business grea aici — doar wiring și randare. */

(function initSportBrandAI() {
  const sb = window.SBAI;
  const cfg = sb.config;
  const $ = (id) => document.getElementById(id);
  const outputs = ['strategyOutput', 'brandOutput', 'contentOutput', 'calendarOutput', 'mediaKitOutput', 'outreachOutput', 'offerOutput'];
  const GAUGE_C = 2 * Math.PI * 52; // circumferința inelului de scor
  let activeOutreachTab = 'email';
  let lastScore = null;
  let livePageId = null;

  sb.showToast = function showToast(text) {
    const toast = $('toast');
    if (!toast) return;
    toast.textContent = text;
    toast.classList.add('show');
    window.setTimeout(() => toast.classList.remove('show'), 1800);
  };

  function populateSports() {
    const select = $('sport');
    select.innerHTML = '';
    sb.olympicSports.forEach((group) => {
      const optgroup = document.createElement('optgroup');
      optgroup.label = group.group;
      group.items.forEach(([value, label]) => {
        const option = document.createElement('option');
        option.value = value;
        option.textContent = label;
        optgroup.appendChild(option);
      });
      select.appendChild(optgroup);
    });
  }

  function getData() {
    return {
      name: $('athleteName').value.trim() || 'Sportivul',
      sport: $('sport').value,
      level: $('level').value,
      goal: $('goal').value,
      results: $('results').value.trim() || 'rezultate în dezvoltare',
      followers: Number($('followers').value || 0),
      city: $('city').value.trim() || 'orașul local',
      audience: $('audience').value,
      tone: $('tone').value,
      frequency: $('frequency').value,
      revenue: $('revenue').value,
      assets: $('assets').value.trim() || 'postări social media, mențiuni publice, apariții video și asociere cu performanța sportivă',
      contactEmail: $('contactEmail') ? $('contactEmail').value.trim() : '',
      contactPhone: $('contactPhone') ? $('contactPhone').value.trim() : ''
    };
  }
  sb.getData = getData;

  // Aplică un set de valori în formular și regenerează (folosit de simulator).
  sb.applyProfilePatch = function applyProfilePatch(patch) {
    Object.entries(patch || {}).forEach(([id, value]) => {
      if ($(id) && value != null) $(id).value = value;
    });
    generate();
  };

  function setGauge(score) {
    const arc = $('gaugeArc');
    if (arc) arc.style.strokeDashoffset = String(GAUGE_C * (1 - score / 100));
    if ($('scoreValue')) $('scoreValue').textContent = score;
  }

  function renderSubScores(breakdown) {
    const host = $('subScores');
    if (!host) return;
    host.innerHTML = breakdown.map((b) => `
      <div class="subscore">
        <div class="subscore-top"><span>${b.label}</span><strong>${b.value}</strong></div>
        <div class="meter"><span style="width:${b.value}%"></span></div>
      </div>`).join('');
  }

  function updateDashboard(data, sc) {
    const p = sb.findProfile(data.sport);
    $('dashScore').textContent = `${sc.total}/100`;
    $('dashLevel').textContent = sc.message;
    $('dashSport').textContent = sb.label(data.sport);
    $('dashCategory').textContent = `Categorie: ${p.label}`;
    $('dashGoal').textContent = sb.goalText(data.goal).split(' prin ')[0];
    $('dashNext').textContent = sc.nextAction;

    $('dashValue').textContent = `${sb.format.lei(sc.value.low)} – ${sb.format.lei(sc.value.high)}`;
    $('dashReach').textContent = `reach lunar estimat ~${sb.format.number(sc.value.reach)}`;

    setGauge(sc.total);
    renderSubScores(sc.breakdown);
    $('scoreText').textContent = sc.message;
  }

  function generate() {
    const data = getData();
    const category = sb.categoryKey(data.sport);
    const sc = sb.score(data, category);
    lastScore = sc;
    updateDashboard(data, sc);

    if (sb.isPremium()) {
      $('strategyOutput').textContent = sb.gen.strategy(data, sc);
      $('brandOutput').textContent = sb.gen.brand(data);
      $('contentOutput').textContent = sb.gen.content(data);
      $('calendarOutput').textContent = sb.gen.calendar(data);
      $('mediaKitOutput').textContent = sb.gen.mediaKit(data, sc);
      $('outreachOutput').textContent = sb.gen.outreach(data, activeOutreachTab);
      $('offerOutput').textContent = sb.gen.offer(data);
    } else {
      $('strategyOutput').textContent = sb.gen.freeStrategy(data);
      $('brandOutput').innerHTML = sb.premium.lockedHTML('Brandul personal');
      $('contentOutput').textContent = sb.gen.freeContent(data);
      $('calendarOutput').innerHTML = sb.premium.lockedHTML('Calendarul pe 30 de zile');
      $('mediaKitOutput').innerHTML = sb.premium.lockedHTML('Media Kit-ul');
      $('outreachOutput').innerHTML = sb.premium.lockedHTML('Sponsor Outreach');
      $('offerOutput').innerHTML = sb.premium.lockedHTML('Pachetele Bronze / Silver / Gold');
    }
    updateLivepagePanel();
    updateOutreachActions(data);
    outputs.forEach((id) => $(id).classList.remove('empty'));
    sb.updatePdfMeta(data, sc.total, sc);
    sb.storage.setJSON('last', { data, generatedAt: new Date().toISOString() });
    if (sb.sim) sb.sim.refresh();
    if (sb.collect && sb.collect.isEnabled() && cfg.collect && cfg.collect.sendOnGenerate) {
      sb.collect.send('profile', sb.collect.rowFromProfile(data, sc));
    }
  }

  sb.regenerateIfReady = function regenerateIfReady() {
    if (!$('strategyOutput').classList.contains('empty')) generate();
    updateLivepagePanel();
    updateRosterPanel();
  };

  function updateLivepagePanel() {
    const on = sb.isPremium();
    $('livepageLocked').style.display = on ? 'none' : '';
    $('livepageActive').style.display = on ? '' : 'none';
    if (!on) $('livepageLinkRow').style.display = 'none';
    const note = $('livepageNote');
    if (note && sb.api && sb.api.flag('shortLinks')) {
      note.innerHTML = 'Link scurt și permanent, salvat pe backend: se actualizează automat când regenerezi profilul, iar mai jos vezi câte vizualizări și click-uri „Contact" a primit.';
    }
    updateAiButtons();
  }

  function updateAiButtons() {
    const show = sb.isPremium() && sb.api && sb.api.flag('ai');
    document.querySelectorAll('.ai-btn').forEach((btn) => {
      btn.style.display = show ? '' : 'none';
    });
  }

  async function runAiRewrite(btn) {
    const kind = btn.dataset.kind;
    const targetId = { strategy: 'strategyOutput', brand: 'brandOutput', outreach: 'outreachOutput' }[kind];
    if (!targetId) return;
    const out = $(targetId);
    if (out.classList.contains('empty')) { sb.showToast('Generează întâi raportul, apoi rescrie cu AI.'); return; }

    const data = getData();
    const sc = lastScore || sb.score(data, sb.categoryKey(data.sport));
    const label = btn.textContent;
    btn.disabled = true;
    btn.textContent = '✦ Se generează…';
    const result = await sb.api.aiGenerate(kind, data, sc);
    btn.disabled = false;
    btn.textContent = label;

    if (result.ok) {
      out.textContent = `✦ GENERAT CU AI — verifică înainte de trimitere\n\n${result.text.trim()}`;
      sb.showToast('Textul a fost rescris cu AI.');
    } else if (result.error === 'no_key') {
      sb.showToast('Backend-ul nu are cheie AI. Adaugă GEMINI_API_KEY în Script Properties (vezi README).');
    } else {
      sb.showToast('Generarea AI a eșuat (rețea sau cotă depășită). Textul pe reguli rămâne valabil.');
    }
  }

  async function refreshLiveStats() {
    if (!livePageId || !sb.api || !sb.api.flag('analytics')) return;
    const stats = await sb.api.getStats(livePageId);
    if (!stats) return;
    if ($('livepageViews')) $('livepageViews').textContent = stats.views;
    if ($('livepageClicks')) $('livepageClicks').textContent = stats.clicks;
  }

  function rosterRowActionsHTML(id) {
    return `
      <div class="roster-row-actions">
        <button type="button" data-action="load" data-id="${id}">Încarcă</button>
        <button type="button" data-action="download" data-id="${id}">Pagină live</button>
        <button type="button" class="danger" data-action="remove" data-id="${id}">Șterge</button>
      </div>`;
  }

  function renderRosterTable() {
    const entries = sb.roster.list();
    const body = $('rosterTableBody');
    if (!entries.length) {
      body.innerHTML = '<tr><td colspan="5" class="roster-empty">Rosterul e gol. Completează un profil mai sus și apasă „Salvează în roster".</td></tr>';
      $('rosterStats').style.display = 'none';
      return;
    }
    const sorted = [...entries].sort((a, b) => b.sc.total - a.sc.total);
    body.innerHTML = sorted.map((e) => {
      const p = sb.share.buildPayload(e.data, e.sc);
      return `<tr>
        <td>${p.name}</td>
        <td>${p.sportLabel}</td>
        <td>${p.score}</td>
        <td>${p.valueLine || '—'}</td>
        <td>${rosterRowActionsHTML(e.id)}</td>
      </tr>`;
    }).join('');

    const stats = sb.roster.stats();
    const statsEl = $('rosterStats');
    statsEl.style.display = '';
    statsEl.innerHTML = `
      <article><span>Sportivi în roster</span><strong>${stats.count}</strong></article>
      <article><span>Scor mediu</span><strong>${stats.avgScore}/100</strong></article>
      <article><span>Valoare lunară (roster)</span><strong>${sb.format.lei(stats.totalValueLow)}–${sb.format.lei(stats.totalValueHigh)}</strong></article>
      <article><span>Cea mai frecventă slăbiciune</span><strong style="font-size:.9rem">${stats.weakestAggLabel || '—'}</strong></article>
    `;
  }

  function updateRosterPanel() {
    const on = sb.isPremium();
    $('rosterLocked').style.display = on ? 'none' : '';
    $('rosterActive').style.display = on ? '' : 'none';
    if (on) renderRosterTable();
  }

  function loadRosterEntryIntoForm(entry) {
    const d = entry.data;
    const map = {
      name: d.name, sport: d.sport, level: d.level, goal: d.goal, results: d.results,
      followers: d.followers, city: d.city, audience: d.audience, tone: d.tone,
      frequency: d.frequency, revenue: d.revenue, assets: d.assets,
      contactEmail: d.contactEmail, contactPhone: d.contactPhone
    };
    Object.entries(map).forEach(([id, value]) => {
      const el = $(id);
      if (el && value != null) el.value = value;
    });
    lastScore = null;
    generate();
    if (sb.views) sb.views.go('profil');
    sb.showToast(`Profilul „${d.name}" a fost încărcat în formular.`);
  }

  function downloadStandaloneFor(data, sc) {
    const html = sb.share.buildStandaloneHTML(data, sc);
    const blob = new Blob([html], { type: 'text/html' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `${sb.slug(data.name) || 'profil'}-sportbrand.html`;
    document.body.appendChild(a);
    a.click();
    a.remove();
    URL.revokeObjectURL(url);
  }

  function getFullText() {
    const plan = sb.isPremium() ? 'PREMIUM' : 'FREE / BASIC';
    return [`PLAN ACCES: ${plan}`, ...outputs.map((id) => $(id).textContent)].join('\n\n--------------------\n\n');
  }

  /* --- Outreach: acțiuni reale (copiere + trimitere) --- */
  function updateOutreachActions(data) {
    const sendLink = $('outreachSend');
    if (!sendLink) return;
    if (!sb.isPremium()) { sendLink.style.display = 'none'; return; }
    const text = sb.gen.outreach(data, activeOutreachTab);
    if (activeOutreachTab === 'whatsapp') {
      sendLink.style.display = '';
      sendLink.textContent = 'Deschide în WhatsApp';
      sendLink.href = sb.links.whatsapp(text);
    } else if (activeOutreachTab === 'email') {
      sendLink.style.display = '';
      sendLink.textContent = 'Deschide în email';
      sendLink.href = sb.links.mailto('Propunere de parteneriat sportiv', text);
    } else {
      sendLink.style.display = 'none';
    }
  }

  /* --- Comandă --- */
  function orderPackageId() {
    const val = $('orderPackage').value;
    const found = Object.values(cfg.prices).find((p) => val.startsWith(p.label));
    return found ? found.id : 'strategy';
  }

  // Rezumat vizibil pentru client (fără cod).
  function buildOrderSummary(data, sc) {
    const clientName = $('clientName').value.trim() || data.name;
    const clientPhone = $('clientPhone').value.trim() || '-';
    const clientEmail = $('clientEmail').value.trim() || '-';
    const notes = $('orderNotes').value.trim() || 'Fără observații suplimentare.';
    const packageName = $('orderPackage').value;
    return `COMANDĂ SPORTBRAND AI\n\nPachet ales: ${packageName}\nClient: ${clientName}\nTelefon: ${clientPhone}\nEmail: ${clientEmail}\nSportiv / club analizat: ${data.name}\nSport: ${sb.label(data.sport)}\nNivel: ${data.level}\nObiectiv: ${sb.goalText(data.goal)}\nSportBrand Score estimativ: ${sc.total}/100\nValoare estimată parteneriat: ${sb.format.lei(sc.value.low)}–${sb.format.lei(sc.value.high)}/lună\n\nObservații client:\n${notes}\n\nCe se livrează:\n- strategie personalizată de promovare sportivă\n- raport PDF premium\n- media kit, dacă pachetul îl include\n- recomandări de sponsorizare + pachete comerciale\n- mesaje inițiale către potențiali sponsori\n- calendar de acțiuni pe 30 de zile\n- cod de acces premium după confirmarea plății`;
  }

  // Mesaj pentru operator (include codul de activat după plată).
  function buildOperatorMessage(data, sc) {
    const email = $('clientEmail').value.trim();
    const code = sb.premium.codeFor(email, orderPackageId());
    return `${buildOrderSummary(data, sc)}\n\n— PENTRU OPERATOR —\nCOD DE ACTIVARE: ${code}\n(Trimite-l clientului DUPĂ confirmarea plății.)`;
  }

  function submitOrder() {
    if ($('strategyOutput').classList.contains('empty')) generate();
    const data = getData();
    const sc = lastScore || sb.score(data, sb.categoryKey(data.sport));
    const email = $('clientEmail').value.trim();
    const phone = $('clientPhone').value.trim();

    if (email && !sb.validate.email(email)) { sb.showToast('Emailul nu pare valid. Verifică adresa.'); $('clientEmail').focus(); return; }
    if (phone && !sb.validate.phone(phone)) { sb.showToast('Telefonul nu pare valid (ex: 07xx xxx xxx).'); $('clientPhone').focus(); return; }

    const summary = buildOrderSummary(data, sc);
    const operatorMsg = buildOperatorMessage(data, sc);

    $('orderOutput').textContent = summary;
    $('orderOutput').classList.remove('empty');

    // Salvează contextul comenzii pentru validarea codului unic.
    sb.storage.setJSON('order_meta', { email, packageId: orderPackageId() });
    sb.storage.set('order', summary);

    // Linkuri de trimitere către operator (conțin codul).
    $('emailOrderBtn').href = sb.links.mailto('Comandă SportBrand AI', operatorMsg, cfg.brand.operatorEmail);
    const wa = $('whatsappOrderBtn');
    if (wa) wa.href = sb.links.whatsapp(operatorMsg, cfg.brand.operatorWhatsApp);

    // Colectare în Google Sheets (dacă e configurat un endpoint).
    if (sb.collect && sb.collect.isEnabled()) {
      sb.collect.send('order', {
        ...sb.collect.rowFromProfile(data, sc),
        clientName: $('clientName').value.trim() || data.name,
        clientEmail: email || '',
        clientPhone: phone || '',
        package: $('orderPackage').value,
        notes: $('orderNotes').value.trim()
      });
      sb.showToast('Comanda a fost generată și înregistrată. Trimite-o pe email sau WhatsApp.');
    } else {
      sb.showToast('Comanda a fost generată. Trimite-o pe email sau WhatsApp.');
    }
  }

  function restoreLastProfile() {
    const last = sb.storage.getJSON('last');
    if (!last || !last.data) return;
    const d = last.data;
    const map = {
      athleteName: d.name === 'Sportivul' ? '' : d.name,
      sport: d.sport, level: d.level, goal: d.goal,
      results: d.results === 'rezultate în dezvoltare' ? '' : d.results,
      followers: d.followers || '',
      city: d.city === 'orașul local' ? '' : d.city,
      audience: d.audience, tone: d.tone, frequency: d.frequency, revenue: d.revenue,
      assets: d.assets || '',
      contactEmail: d.contactEmail || '',
      contactPhone: d.contactPhone || ''
    };
    Object.entries(map).forEach(([id, value]) => { if ($(id) && value !== undefined) $(id).value = value; });
  }

  function bindEvents() {
    $('athleteForm').addEventListener('submit', (e) => { e.preventDefault(); generate(); if (sb.views) sb.views.go('raport'); });
    $('generateTop').addEventListener('click', () => { generate(); if (sb.views) sb.views.go('raport'); });

    $('activatePremiumBtn').addEventListener('click', async () => {
      const value = $('premiumCode').value;
      if (!value.trim()) { sb.showToast('Introdu codul premium.'); return; }
      const btn = $('activatePremiumBtn');
      const label = btn.textContent;
      btn.disabled = true;
      if (sb.api && sb.api.flag('serverCodes')) btn.textContent = 'Se verifică…';
      const ok = await sb.premium.validateAsync(value);
      btn.disabled = false;
      btn.textContent = label;
      if (ok) sb.premium.setState(true);
      else sb.showToast('Cod premium invalid. Verifică plata sau cere codul de acces.');
    });
    $('resetPremiumBtn').addEventListener('click', () => sb.premium.setState(false));

    $('generateLiveBtn').addEventListener('click', async () => {
      if (!sb.isPremium()) { sb.showToast('Pagina Live necesită acces premium.'); return; }
      const data = getData();
      const sc = lastScore || sb.score(data, sb.categoryKey(data.sport));

      if (sb.api && sb.api.flag('shortLinks')) {
        const id = sb.share.shortId(data);
        const payload = sb.share.buildPayload(data, sc);
        sb.api.savePage(id, payload); // fire-and-forget
        const link = sb.share.buildShortLink(id);
        $('livepageLink').value = link;
        $('openLiveLinkBtn').href = link;
        $('livepageLinkRow').style.display = '';
        livePageId = id;
        if (sb.api.flag('analytics')) {
          $('livepageStats').style.display = '';
          refreshLiveStats();
        }
        sb.showToast('Link scurt generat. Pagina se actualizează la fiecare regenerare.');
      } else {
        const link = sb.share.buildLink(data, sc);
        $('livepageLink').value = link;
        $('openLiveLinkBtn').href = link;
        $('livepageLinkRow').style.display = '';
        sb.showToast('Linkul paginii live a fost generat.');
      }
    });
    $('copyLiveLinkBtn').addEventListener('click', async () => {
      const ok = await sb.copy($('livepageLink').value);
      sb.showToast(ok ? 'Linkul a fost copiat.' : 'Copierea nu a reușit. Selectează manual linkul.');
    });
    const statsRefresh = $('livepageStatsRefresh');
    if (statsRefresh) statsRefresh.addEventListener('click', refreshLiveStats);

    document.querySelectorAll('.ai-btn').forEach((btn) => {
      btn.addEventListener('click', () => runAiRewrite(btn));
    });
    $('downloadLiveBtn').addEventListener('click', () => {
      if (!sb.isPremium()) { sb.showToast('Pagina Live necesită acces premium.'); return; }
      const data = getData();
      const sc = lastScore || sb.score(data, sb.categoryKey(data.sport));
      downloadStandaloneFor(data, sc);
      sb.showToast('Pagina independentă a fost descărcată.');
    });

    $('rosterSaveBtn').addEventListener('click', () => {
      if (!sb.isPremium()) { sb.showToast('Rosterul de club necesită acces premium.'); return; }
      const data = getData();
      if (!data.name) { sb.showToast('Completează numele sportivului înainte de a salva.'); return; }
      const sc = lastScore || sb.score(data, sb.categoryKey(data.sport));
      sb.roster.save(data, sc);
      renderRosterTable();
      sb.showToast(`„${data.name}" a fost salvat în roster.`);
    });

    $('rosterTableBody').addEventListener('click', (e) => {
      const btn = e.target.closest('button[data-action]');
      if (!btn) return;
      const entry = sb.roster.get(btn.dataset.id);
      if (!entry) return;
      if (btn.dataset.action === 'load') {
        loadRosterEntryIntoForm(entry);
      } else if (btn.dataset.action === 'download') {
        downloadStandaloneFor(entry.data, entry.sc);
        sb.showToast(`Pagina live pentru „${entry.data.name}" a fost descărcată.`);
      } else if (btn.dataset.action === 'remove') {
        sb.roster.remove(entry.id);
        renderRosterTable();
        sb.showToast(`„${entry.data.name}" a fost șters din roster.`);
      }
    });

    $('rosterExportLiveBtn').addEventListener('click', () => {
      const entries = sb.roster.list();
      if (!entries.length) { sb.showToast('Rosterul e gol.'); return; }
      entries.forEach((entry, i) => {
        setTimeout(() => downloadStandaloneFor(entry.data, entry.sc), i * 350);
      });
      sb.showToast(`Se descarcă ${entries.length} pagini live…`);
    });

    $('rosterExportJsonBtn').addEventListener('click', () => {
      const json = sb.roster.exportJSON();
      const blob = new Blob([json], { type: 'application/json' });
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `roster-sportbrand-${new Date().toISOString().slice(0, 10)}.json`;
      document.body.appendChild(a);
      a.click();
      a.remove();
      URL.revokeObjectURL(url);
      sb.showToast('Rosterul a fost exportat (JSON).');
    });

    $('rosterImportInput').addEventListener('change', (e) => {
      const file = e.target.files && e.target.files[0];
      if (!file) return;
      const reader = new FileReader();
      reader.onload = () => {
        const result = sb.roster.importJSON(String(reader.result), 'merge');
        if (result.ok) {
          renderRosterTable();
          sb.showToast(`${result.count} sportivi importați în roster.`);
        } else {
          sb.showToast(result.error || 'Import eșuat.');
        }
        e.target.value = '';
      };
      reader.readAsText(file);
    });

    $('rosterClearBtn').addEventListener('click', () => {
      if (!sb.roster.list().length) return;
      if (!window.confirm('Ștergi definitiv tot rosterul din acest browser?')) return;
      sb.roster.clear();
      renderRosterTable();
      sb.showToast('Rosterul a fost golit.');
    });

    $('rosterOpenClubReport').addEventListener('click', () => {
      if (!sb.roster.list().length) { sb.showToast('Rosterul e gol.'); return; }
      window.open(sb.roster.buildClubReportLink(), '_blank', 'noopener');
    });

    // Tab-uri outreach cu ARIA + navigare cu săgeți.
    const tabs = Array.from(document.querySelectorAll('.tab'));
    function selectTab(button) {
      activeOutreachTab = button.dataset.tab;
      tabs.forEach((t) => {
        const on = t === button;
        t.classList.toggle('active', on);
        t.setAttribute('aria-selected', on ? 'true' : 'false');
        t.tabIndex = on ? 0 : -1;
      });
      const data = getData();
      if (sb.isPremium() && !$('outreachOutput').classList.contains('empty')) {
        $('outreachOutput').textContent = sb.gen.outreach(data, activeOutreachTab);
      }
      updateOutreachActions(data);
    }
    tabs.forEach((button, i) => {
      button.addEventListener('click', () => selectTab(button));
      button.addEventListener('keydown', (e) => {
        if (e.key === 'ArrowRight' || e.key === 'ArrowLeft') {
          e.preventDefault();
          const dir = e.key === 'ArrowRight' ? 1 : -1;
          const next = tabs[(i + dir + tabs.length) % tabs.length];
          next.focus(); selectTab(next);
        }
      });
    });

    $('copyOutreachBtn').addEventListener('click', async () => {
      const ok = await sb.copy($('outreachOutput').textContent);
      sb.showToast(ok ? 'Mesajul a fost copiat.' : 'Copierea nu a reușit. Selectează manual textul.');
    });

    $('copyBtn').addEventListener('click', async () => {
      const ok = await sb.copy(getFullText());
      sb.showToast(ok ? 'Raportul a fost copiat.' : 'Copierea nu a reușit. Selectează manual textul.');
    });
    $('saveBtn').addEventListener('click', () => {
      const ok = sb.storage.set('strategy', getFullText());
      sb.showToast(ok ? 'Strategia a fost salvată local.' : 'Salvarea locală nu e disponibilă (navigare privată?).');
    });
    $('printBtn').addEventListener('click', () => {
      if (!sb.isPremium()) { if (sb.views) sb.views.go('premium'); sb.showToast('Exportul PDF premium necesită cod de acces.'); return; }
      if ($('strategyOutput').classList.contains('empty')) generate();
      window.print();
    });
    window.addEventListener('beforeprint', () => {
      if (sb.isPremium()) {
        if ($('strategyOutput').classList.contains('empty')) generate();
        const data = getData();
        const sc = lastScore || sb.score(data, sb.categoryKey(data.sport));
        sb.updatePdfMeta(data, sc.total, sc);
      }
    });

    document.querySelectorAll('.packageBtn').forEach((btn) => {
      btn.addEventListener('click', () => {
        $('orderPackage').value = btn.dataset.package;
        $('comanda').scrollIntoView({ behavior: 'smooth', block: 'start' });
        sb.showToast('Pachetul a fost selectat.');
      });
    });

    $('orderForm').addEventListener('submit', (e) => { e.preventDefault(); submitOrder(); });
    $('copyOrderBtn').addEventListener('click', async () => {
      if ($('orderOutput').classList.contains('empty')) submitOrder();
      const ok = await sb.copy($('orderOutput').textContent);
      sb.showToast(ok ? 'Comanda a fost copiată.' : 'Copierea nu a reușit. Selectează manual textul.');
    });
  }

  // Init
  populateSports();
  restoreLastProfile();
  bindEvents();
  if (!sb.storage.available()) sb.showToast('Navigare privată: profilul nu va fi reținut între sesiuni.');
  sb.premium.setState(sb.premium.isPremium(), true);
  updateLivepagePanel();
  updateRosterPanel();
  const savedOrder = sb.storage.get('order');
  if (savedOrder) { $('orderOutput').textContent = savedOrder; $('orderOutput').classList.remove('empty'); }
})();
