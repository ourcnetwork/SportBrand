'use strict';

/* Pagina Live pentru Sponsori.
   Codifică datele profilului + scorul într-un payload compact, plasat direct
   în linkul de pagină (fragment #d=...) — fără server, fără bază de date.
   NOTĂ ONESTĂ: linkul e „stateless": funcționează cât timp brand.html rămâne
   lângă restul proiectului. Nu e un link scurt/permanent per atlet — asta ar
   cere un backend care generează și găzduiește pagini reale. Vezi README. */

window.SBAI = window.SBAI || {};

(function share() {
  const sb = window.SBAI;

  function b64urlEncode(str) {
    const b64 = btoa(unescape(encodeURIComponent(str)));
    return b64.replace(/\+/g, '-').replace(/\//g, '_').replace(/=+$/, '');
  }

  function b64urlDecode(str) {
    let b64 = String(str || '').replace(/-/g, '+').replace(/_/g, '/');
    while (b64.length % 4) b64 += '=';
    return decodeURIComponent(escape(atob(b64)));
  }

  // Construiește payload-ul afișabil (deja formatat), ca brand.html
  // să nu aibă nevoie de sports-data.js / generators.js pentru randare.
  function buildPayload(data, sc) {
    const p = sb.findProfile(data.sport);
    return {
      v: 1,
      name: data.name,
      sportLabel: sb.label(data.sport),
      categoryLabel: p.label,
      level: data.level,
      city: data.city,
      goalLabel: sb.goalText(data.goal),
      results: data.results,
      assets: data.assets,
      followersFormatted: sb.format.number(data.followers || 0),
      contactEmail: (data.contactEmail || '').trim(),
      contactPhone: (data.contactPhone || '').trim(),
      score: sc ? sc.total : 0,
      breakdown: sc ? sc.breakdown.map((b) => ({ label: b.label, value: b.value })) : [],
      weakestLabel: sc && sc.weakest ? sc.weakest.label : '',
      nextAction: sc ? sc.nextAction : '',
      valueLine: sc && sc.value ? `${sb.format.lei(sc.value.low)}–${sb.format.lei(sc.value.high)}/lună` : '',
      reachFormatted: sc && sc.value ? sb.format.number(sc.value.reach) : '',
      sponsors: p.sponsors,
      bio: `${data.name} este un profil sportiv construit în jurul performanței, disciplinei și progresului în ${sb.label(data.sport)}. Rezultate relevante: ${data.results}.`,
      generatedDate: sb.format.dateLong(new Date())
    };
  }

  function encode(data, sc) {
    return b64urlEncode(JSON.stringify(buildPayload(data, sc)));
  }

  function decodeFromHash(hash) {
    const source = hash || window.location.hash || '';
    const m = /d=([^&]+)/.exec(source);
    if (!m) return null;
    try { return JSON.parse(b64urlDecode(m[1])); } catch (e) { return null; }
  }

  // Link relativ la brand.html, care stă lângă index.html în același folder.
  function buildLink(data, sc) {
    const encoded = encode(data, sc);
    const base = window.location.href.split('#')[0].replace(/[^/]*$/, '');
    return `${base}brand.html#d=${encoded}`;
  }

  // ID scurt, determinist per atlet (același atlet → același link scurt, care
  // se actualizează la regenerare). FNV-1a → base36.
  function shortId(data) {
    const seed = `${(data.name || '').toLowerCase().trim()}|${data.sport}|${(data.contactEmail || '').toLowerCase().trim()}`;
    let h = 0x811c9dc5;
    for (let i = 0; i < seed.length; i++) {
      h ^= seed.charCodeAt(i);
      h = (h + ((h << 1) + (h << 4) + (h << 7) + (h << 8) + (h << 24))) >>> 0;
    }
    return `p${h.toString(36)}`;
  }

  // Link scurt către o pagină stocată pe backend (brand.html?p=ID).
  function buildShortLink(id) {
    const base = window.location.href.split('#')[0].split('?')[0].replace(/[^/]*$/, '');
    return `${base}brand.html?p=${encodeURIComponent(id)}`;
  }

  function esc(str) {
    return String(str == null ? '' : str).replace(/[&<>"']/g, (c) => ({
      '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;'
    }[c]));
  }

  // Randează conținutul paginii publice dintr-un payload deja formatat.
  // Folosit atât de brand.html (citește din URL) cât și de exportul
  // independent (HTML static, fără JS necesar la afișare).
  function renderBody(payload) {
    const d = payload || {};
    const score = Number(d.score) || 0;
    const circumference = 2 * Math.PI * 52;
    const offset = circumference * (1 - score / 100);
    const bars = (d.breakdown || []).map((b) => `
      <div class="bs-row">
        <span class="bs-label">${esc(b.label)}</span>
        <div class="bs-track"><div class="bs-fill" style="width:${Math.max(0, Math.min(100, b.value))}%"></div></div>
        <span class="bs-value">${Math.round(b.value)}</span>
      </div>`).join('');

    const hasEmail = Boolean(d.contactEmail);
    const hasPhone = Boolean(d.contactPhone);
    const subject = encodeURIComponent(`Parteneriat sponsor — ${d.name || 'profil sportiv'}`);
    const body = encodeURIComponent(`Bună ziua ${d.name || ''},\n\nAm văzut pagina dumneavoastră SportBrand AI și aș dori să discutăm un posibil parteneriat de sponsorizare.\n\nCu stimă,`);
    let ctaHref = '';
    if (hasEmail) ctaHref = `mailto:${d.contactEmail}?subject=${subject}&body=${body}`;
    else if (hasPhone) ctaHref = `tel:${d.contactPhone.replace(/\s+/g, '')}`;

    const ctaBlock = ctaHref
      ? `<a class="bp-cta" href="${esc(ctaHref)}">Contactează pentru parteneriat</a>`
      : `<p class="bp-cta-note">Sportivul nu a adăugat încă un email/telefon de contact în profil.</p>`;

    return `
      <header class="bp-header">
        <span class="bp-mark">SB</span>
        <div>
          <strong>SportBrand AI</strong>
          <small>Pagină live · generată ${esc(d.generatedDate || '')}</small>
        </div>
      </header>

      <section class="bp-hero">
        <div class="bp-gauge">
          <svg viewBox="0 0 150 150" width="150" height="150">
            <circle cx="75" cy="75" r="52" class="bp-track"></circle>
            <circle cx="75" cy="75" r="52" class="bp-arc" stroke-dasharray="${circumference.toFixed(2)}" stroke-dashoffset="${offset.toFixed(2)}" transform="rotate(-90 75 75)"></circle>
          </svg>
          <div class="bp-gauge-value"><span>${score}</span><small>/100</small></div>
        </div>
        <div class="bp-hero-text">
          <h1>${esc(d.name)}</h1>
          <p class="bp-tags">${esc(d.sportLabel)} · ${esc(d.categoryLabel)} · ${esc(d.city)} · nivel ${esc(d.level)}</p>
          <p class="bp-goal">Obiectiv: ${esc(d.goalLabel)}</p>
        </div>
      </section>

      ${d.valueLine ? `<section class="bp-value">
        <strong>${esc(d.valueLine)}</strong>
        <span>valoare orientativă de parteneriat · reach lunar estimat ~${esc(d.reachFormatted)}</span>
      </section>` : ''}

      <section class="bp-block">
        <h2>Detaliere scor</h2>
        <div class="bp-bars">${bars}</div>
      </section>

      <section class="bp-block">
        <h2>Despre</h2>
        <p>${esc(d.bio)}</p>
      </section>

      <div class="bp-two">
        <section class="bp-block">
          <h2>Ce poate oferi</h2>
          <p>${esc(d.assets)}</p>
        </section>
        <section class="bp-block">
          <h2>Sponsori potriviți</h2>
          <p>${esc(d.sponsors)}</p>
        </section>
      </div>

      <section class="bp-block bp-followers">
        <span>Urmăritori social media</span><strong>${esc(d.followersFormatted)}</strong>
      </section>

      <section class="bp-block bp-cta-block">
        <h2>Interesat de un parteneriat?</h2>
        ${ctaBlock}
      </section>

      <footer class="bp-footer">Generat cu SportBrand AI · valorile sunt orientative, nu reprezintă o garanție contractuală.</footer>
    `;
  }

  const CSS = `:root{color-scheme:dark;--bg:#0B0F1C;--surface:#131A2B;--elev:#1A2236;--text:#EEF1F8;--muted:#8B94A9;--line:rgba(255,255,255,.10);--gold:#F5B841;--gold-ink:#0B0F1C;--cyan:#37D6CE}
*{box-sizing:border-box}body{margin:0;background:var(--bg);color:var(--text);font-family:Inter,system-ui,-apple-system,"Segoe UI",sans-serif}
.bp-wrap{max-width:720px;margin:0 auto;padding:28px 20px 60px}
.bp-header{display:flex;align-items:center;gap:12px;margin-bottom:24px}
.bp-header strong{display:block;font-size:.95rem}.bp-header small{color:var(--muted);font-size:.78rem}
.bp-mark{width:36px;height:36px;border-radius:10px;background:var(--gold);color:var(--gold-ink);display:flex;align-items:center;justify-content:center;font-weight:800;font-family:"Space Mono",monospace}
.bp-hero{display:flex;align-items:center;gap:22px;background:var(--surface);border:1px solid var(--line);border-radius:22px;padding:22px;margin-bottom:18px;flex-wrap:wrap}
.bp-gauge{position:relative;width:150px;height:150px;flex:none}
.bp-track{fill:none;stroke:var(--line);stroke-width:10}
.bp-arc{fill:none;stroke:var(--gold);stroke-width:10;stroke-linecap:round;transition:stroke-dashoffset .6s ease}
.bp-gauge-value{position:absolute;inset:0;display:flex;flex-direction:column;align-items:center;justify-content:center;font-family:"Space Mono",monospace}
.bp-gauge-value span{font-size:2.1rem;font-weight:700}.bp-gauge-value small{color:var(--muted)}
.bp-hero-text{flex:1 1 240px}
.bp-hero-text h1{margin:0 0 6px;font-size:1.6rem;font-family:Archivo,system-ui,sans-serif}
.bp-tags{color:var(--muted);margin:0 0 8px}
.bp-goal{margin:0;color:var(--cyan)}
.bp-value{background:linear-gradient(135deg,rgba(245,184,65,.16),rgba(55,214,206,.10));border:1px solid var(--line);border-radius:18px;padding:16px 20px;margin-bottom:18px}
.bp-value strong{display:block;font-size:1.3rem;font-family:"Space Mono",monospace;color:var(--gold)}
.bp-value span{color:var(--muted);font-size:.85rem}
.bp-block{background:var(--surface);border:1px solid var(--line);border-radius:18px;padding:18px 20px;margin-bottom:14px}
.bp-block h2{margin:0 0 10px;font-size:.95rem;text-transform:uppercase;letter-spacing:.04em;color:var(--muted)}
.bp-block p{margin:0;line-height:1.5}
.bp-two{display:grid;grid-template-columns:1fr 1fr;gap:14px}
.bs-row{display:grid;grid-template-columns:1fr 3fr auto;gap:10px;align-items:center;margin-bottom:8px;font-size:.85rem}
.bs-track{height:8px;background:var(--elev);border-radius:6px;overflow:hidden}
.bs-fill{height:100%;background:var(--cyan);border-radius:6px}
.bs-value{font-family:"Space Mono",monospace;color:var(--muted);text-align:right}
.bp-followers{display:flex;justify-content:space-between;align-items:center}
.bp-followers strong{font-family:"Space Mono",monospace;font-size:1.1rem}
.bp-cta-block{text-align:center}
.bp-cta{display:inline-block;margin-top:6px;background:var(--gold);color:var(--gold-ink);font-weight:700;padding:14px 26px;border-radius:12px;text-decoration:none}
.bp-cta-note{color:var(--muted);font-size:.85rem}
.bp-footer{text-align:center;color:var(--muted);font-size:.78rem;margin-top:20px}
@media(max-width:560px){.bp-two{grid-template-columns:1fr}.bp-hero{flex-direction:column;text-align:center}}`;

  // Export HTML static, complet independent (CSS + conținut deja randat),
  // ce poate fi găzduit oriunde (ex. GitHub Pages) fără restul proiectului.
  function buildStandaloneHTML(data, sc) {
    const payload = buildPayload(data, sc);
    const title = `${payload.name || 'Profil sportiv'} · SportBrand AI`;
    return `<!doctype html>
<html lang="ro">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>${esc(title)}</title>
<style>${CSS}</style>
</head>
<body>
<div class="bp-wrap">${renderBody(payload)}</div>
</body>
</html>`;
  }

  sb.share = { encode, decodeFromHash, buildLink, buildShortLink, shortId, buildPayload, renderBody, css: CSS, buildStandaloneHTML, encodeString: b64urlEncode, decodeString: b64urlDecode };
})();
