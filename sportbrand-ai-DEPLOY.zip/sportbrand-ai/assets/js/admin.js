'use strict';

/* Consola operatorului.
   Cheia se verifică pe server: prima cerere admin_summary cu cheia introdusă
   fie întoarce datele (cheie bună), fie unauthorized (cheie greșită). Cheia
   validată se ține minte în localStorage-ul acestui browser. */

(function admin() {
  const sb = window.SBAI;
  const $ = (id) => document.getElementById(id);
  const KEY_STORAGE = 'sbai_admin_key';

  function esc(str) {
    return String(str == null ? '' : str).replace(/[&<>"']/g, (c) => ({
      '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;'
    }[c]));
  }

  function fmtDate(iso) {
    if (!iso) return '—';
    try {
      return new Date(iso).toLocaleString('ro-RO', { day: '2-digit', month: 'short', hour: '2-digit', minute: '2-digit' });
    } catch (_) { return String(iso); }
  }

  function shortLinkFor(id) {
    const base = window.location.href.split('#')[0].split('?')[0].replace(/[^/]*$/, '');
    return `${base}brand.html?p=${encodeURIComponent(id)}`;
  }

  function setGateMsg(msg) { $('adGateMsg').textContent = msg || ''; }

  function renderCards(s) {
    $('adCards').innerHTML = `
      <article><span>Comenzi primite</span><strong>${s.orders}</strong></article>
      <article><span>Lead-uri totale</span><strong>${s.leads}</strong></article>
      <article><span>Coduri premium active</span><strong>${s.activeCodes}</strong></article>
      <article><span>Pagini live</span><strong>${s.pages}</strong></article>
      <article><span>Vizualizări totale</span><strong class="cyan">${s.views}</strong></article>
      <article><span>Click-uri „Contact"</span><strong class="cyan">${s.clicks}</strong></article>
    `;
  }

  function renderPages(pages) {
    const body = $('adPagesBody');
    if (!pages || !pages.length) {
      body.innerHTML = '<tr><td colspan="6" class="empty">Nicio pagină live încă. Se creează din aplicație, secțiunea „Pagina Live".</td></tr>';
      return;
    }
    body.innerHTML = pages.map((p) => `
      <tr>
        <td>${esc(p.name || p.id)}</td>
        <td class="mono">${esc(p.score)}</td>
        <td class="mono">${p.views}</td>
        <td class="mono ${p.clicks > 0 ? 'hot' : ''}">${p.clicks}</td>
        <td>${esc(fmtDate(p.lastAt || p.updatedAt))}</td>
        <td><a href="${esc(shortLinkFor(p.id))}" target="_blank" rel="noopener" style="color:var(--cyan)">deschide</a></td>
      </tr>`).join('');
  }

  function renderLeads(leads) {
    const body = $('adLeadsBody');
    if (!leads || !leads.length) {
      body.innerHTML = '<tr><td colspan="7" class="empty">Niciun lead încă.</td></tr>';
      return;
    }
    body.innerHTML = leads.map((l) => `
      <tr>
        <td>${esc(fmtDate(l.sentAt))}</td>
        <td class="mono">${esc(l.type)}</td>
        <td>${esc(l.clientName || l.name)}</td>
        <td>${esc(l.clientEmail || l.clientPhone || '—')}</td>
        <td>${esc(l.packageName || '—')}</td>
        <td>${esc(l.sport)}</td>
        <td class="mono">${esc(l.score)}</td>
      </tr>`).join('');
  }

  async function loadDashboard(key) {
    const summary = await sb.api.adminSummary(key);
    if (!summary) return false;
    renderCards(summary);
    $('adGate').classList.add('hidden');
    $('adDash').classList.remove('hidden');
    $('adRefresh').classList.remove('hidden');
    $('adLogout').classList.remove('hidden');
    // pagini + leads în paralel
    sb.api.adminPages(key).then(renderPages);
    sb.api.adminLeads(key, 25).then(renderLeads);
    return true;
  }

  async function tryEnter(key, silent) {
    if (!sb.api.enabled()) {
      setGateMsg('Backend-ul nu e configurat: completează collect.sheetsEndpoint în assets/js/config.js.');
      return;
    }
    if (!key) { if (!silent) setGateMsg('Introdu cheia.'); return; }
    setGateMsg('Se verifică…');
    const ok = await loadDashboard(key);
    if (ok) {
      setGateMsg('');
      try { localStorage.setItem(KEY_STORAGE, key); } catch (_) {}
    } else if (!silent) {
      setGateMsg('Cheie respinsă de server sau backend inaccesibil.');
    } else {
      setGateMsg('');
    }
  }

  function currentKey() {
    try { return localStorage.getItem(KEY_STORAGE) || ''; } catch (_) { return ''; }
  }

  $('adEnter').addEventListener('click', () => tryEnter($('adKey').value.trim(), false));
  $('adKey').addEventListener('keydown', (e) => { if (e.key === 'Enter') tryEnter($('adKey').value.trim(), false); });
  $('adRefresh').addEventListener('click', () => loadDashboard(currentKey()));
  $('adLogout').addEventListener('click', () => {
    try { localStorage.removeItem(KEY_STORAGE); } catch (_) {}
    window.location.reload();
  });
  $('adBack').addEventListener('click', () => { window.location.href = 'index.html'; });

  // auto-login dacă cheia e deja salvată în acest browser
  const saved = currentKey();
  if (saved) tryEnter(saved, true);
})();
