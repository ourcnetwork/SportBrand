'use strict';

/* Strat de servicii. Utilitare reutilizabile, izolate de logica de business:
   - storage: localStorage sigur (nu crapă în navigare privată)
   - clipboard: copiere cu fallback pentru file:// și contexte nesecurizate
   - format: numere și sume în ro-RO
   - validate: email / telefon
   - links: mailto + WhatsApp pregătite pentru trimitere reală */

window.SBAI = window.SBAI || {};

(function services() {
  const NS = 'sportbrand_ai_';

  /* --- Storage sigur --- */
  const storage = {
    available() {
      try {
        const k = NS + 'test';
        window.localStorage.setItem(k, '1');
        window.localStorage.removeItem(k);
        return true;
      } catch (_) {
        return false;
      }
    },
    get(key) {
      try { return window.localStorage.getItem(NS + key); } catch (_) { return null; }
    },
    getJSON(key) {
      const raw = this.get(key);
      if (!raw) return null;
      try { return JSON.parse(raw); } catch (_) { return null; }
    },
    set(key, value) {
      try { window.localStorage.setItem(NS + key, value); return true; } catch (_) { return false; }
    },
    setJSON(key, value) {
      try { return this.set(key, JSON.stringify(value)); } catch (_) { return false; }
    },
    remove(key) {
      try { window.localStorage.removeItem(NS + key); } catch (_) {}
    }
  };

  /* --- Clipboard cu fallback --- */
  async function copy(text) {
    try {
      if (navigator.clipboard && window.isSecureContext) {
        await navigator.clipboard.writeText(text);
        return true;
      }
    } catch (_) { /* cade pe fallback */ }
    try {
      const ta = document.createElement('textarea');
      ta.value = text;
      ta.setAttribute('readonly', '');
      ta.style.position = 'fixed';
      ta.style.top = '-1000px';
      ta.style.opacity = '0';
      document.body.appendChild(ta);
      ta.select();
      const ok = document.execCommand('copy');
      document.body.removeChild(ta);
      return ok;
    } catch (_) {
      return false;
    }
  }

  /* --- Formatare ro-RO --- */
  const nf = new Intl.NumberFormat('ro-RO');
  const format = {
    number: (n) => nf.format(Math.round(Number(n) || 0)),
    lei: (n) => `${nf.format(Math.round(Number(n) || 0))} lei`,
    dateLong: (d = new Date()) => d.toLocaleDateString('ro-RO', { year: 'numeric', month: 'long', day: 'numeric' })
  };

  /* --- Validare --- */
  const validate = {
    email: (v) => /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(String(v || '').trim()),
    // acceptă formate RO uzuale: 07xx xxx xxx, +40..., cu spații/puncte/liniuțe
    phone: (v) => /^(\+?4?0|0)?\s*7\d{2}[\s.-]?\d{3}[\s.-]?\d{3}$/.test(String(v || '').trim())
  };

  /* --- Linkuri de outreach reale --- */
  const links = {
    mailto: (subject, body, to = '') =>
      `mailto:${encodeURIComponent(to)}?subject=${encodeURIComponent(subject)}&body=${encodeURIComponent(body)}`,
    whatsapp: (text, phone = '') => {
      const p = String(phone || '').replace(/\D/g, '');
      const base = p ? `https://wa.me/${p}` : 'https://wa.me/';
      return `${base}?text=${encodeURIComponent(text)}`;
    }
  };

  window.SBAI.storage = storage;
  window.SBAI.copy = copy;
  window.SBAI.format = format;
  window.SBAI.validate = validate;
  window.SBAI.links = links;
})();
