'use strict';

(function brandView() {
  const sb = window.SBAI;
  const styleEl = document.getElementById('bp-style');
  if (styleEl) styleEl.textContent = sb.share.css;
  const app = document.getElementById('bpApp');

  function getParam(name) {
    const m = new RegExp('[?&]' + name + '=([^&]+)').exec(window.location.search || '');
    return m ? decodeURIComponent(m[1]) : null;
  }

  function showInvalid() {
    app.innerHTML = '<p style="text-align:center;color:#8B94A9;padding:60px 20px;max-width:480px;margin:0 auto">' +
      'Linkul pare incomplet sau invalid. Cere sportivului un link nou, generat din SportBrand AI.</p>';
  }

  function render(payload, pageId) {
    if (!payload) { showInvalid(); return; }
    app.innerHTML = sb.share.renderBody(payload);
    document.title = `${payload.name || 'Profil sportiv'} · SportBrand AI`;

    if (!pageId || !sb.api || !sb.api.flag('analytics')) return;
    // înregistrează o vizualizare (trimite și uită)
    sb.api.logEvent(pageId, 'view');
    // înregistrează click pe „Contactează pentru parteneriat"
    const cta = app.querySelector('.bp-cta');
    if (cta) {
      cta.addEventListener('click', () => { sb.api.logEvent(pageId, 'click'); });
    }
  }

  // 1) Date încorporate (export independent) — au prioritate.
  if (window.SBAI_EMBEDDED_DATA) { render(window.SBAI_EMBEDDED_DATA, null); return; }

  // 2) Link scurt: brand.html?p=ID → citește pagina de pe backend.
  const pageId = getParam('p');
  if (pageId && sb.api && sb.api.flag('shortLinks')) {
    app.innerHTML = '<p style="text-align:center;color:#8B94A9;padding:60px 20px">Se încarcă profilul…</p>';
    sb.api.getPage(pageId).then((payload) => render(payload, pageId)).catch(showInvalid);
    return;
  }

  // 3) Fallback stateless: brand.html#d=... (datele în adresă).
  render(sb.share.decodeFromHash(), null);
})();
