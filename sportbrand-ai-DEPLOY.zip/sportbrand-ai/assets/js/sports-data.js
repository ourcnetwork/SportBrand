'use strict';

window.SBAI = window.SBAI || {};

window.SBAI.olympicSports = [
  { group: 'LA 2028 · Sporturi de vară', items: [
    ['aquatics', 'Aquatics / Natație, sărituri, polo, înot artistic'],
    ['archery', 'Archery / Tir cu arcul'], ['athletics', 'Athletics / Atletism'], ['badminton', 'Badminton'],
    ['baseball-softball', 'Baseball / Softball'], ['basketball', 'Basketball / Baschet'], ['boxing', 'Boxing / Box'],
    ['canoe', 'Canoe / Kaiac-canoe'], ['cricket', 'Cricket'], ['cycling', 'Cycling / Ciclism'],
    ['equestrian', 'Equestrian / Echitație'], ['fencing', 'Fencing / Scrimă'], ['flag-football', 'Flag Football'],
    ['football', 'Football / Fotbal'], ['golf', 'Golf'], ['gymnastics', 'Gymnastics / Gimnastică'], ['handball', 'Handball'],
    ['hockey', 'Hockey'], ['judo', 'Judo'], ['lacrosse', 'Lacrosse'], ['modern-pentathlon', 'Modern Pentathlon / Pentatlon modern'],
    ['rowing', 'Rowing / Canotaj'], ['rugby-sevens', 'Rugby Sevens'], ['sailing', 'Sailing / Yachting'], ['shooting', 'Shooting / Tir sportiv'],
    ['skateboarding', 'Skateboarding'], ['sport-climbing', 'Sport Climbing / Escaladă sportivă'], ['squash', 'Squash'], ['surfing', 'Surfing'],
    ['table-tennis', 'Table Tennis / Tenis de masă'], ['taekwondo', 'Taekwondo'], ['tennis', 'Tennis / Tenis'], ['triathlon', 'Triathlon'],
    ['volleyball', 'Volleyball / Volei'], ['weightlifting', 'Weightlifting / Haltere'], ['wrestling', 'Wrestling / Lupte']
  ]},
  { group: 'Milano Cortina 2026 · Sporturi și discipline de iarnă', items: [
    ['alpine-skiing', 'Alpine Skiing / Schi alpin'], ['biathlon', 'Biathlon'], ['bobsleigh', 'Bobsleigh'],
    ['cross-country-skiing', 'Cross-Country Skiing / Schi fond'], ['curling', 'Curling'], ['figure-skating', 'Figure Skating / Patinaj artistic'],
    ['freestyle-skiing', 'Freestyle Skiing'], ['ice-hockey', 'Ice Hockey / Hochei pe gheață'], ['luge', 'Luge / Sanie'],
    ['nordic-combined', 'Nordic Combined / Combinată nordică'], ['short-track', 'Short Track Speed Skating'], ['skeleton', 'Skeleton'],
    ['ski-jumping', 'Ski Jumping / Sărituri cu schiurile'], ['snowboard', 'Snowboard'], ['speed-skating', 'Speed Skating / Patinaj viteză']
  ]}
];

window.SBAI.sportProfiles = {
  combat: {
    label: 'Sport de duel / contact', sports: ['boxing', 'judo', 'taekwondo', 'wrestling', 'fencing'],
    angle: 'disciplină, duel, curaj, control mental și respect pentru adversar',
    sponsors: 'săli de sport, echipament, suplimente, recuperare, clinici, firme locale puternice',
    products: 'seminarii, cursuri de inițiere, programe de condiționare, autoapărare, masterclass-uri',
    content: ['sparring controlat', 'tehnică explicată lent', 'pregătire mentală înainte de competiție']
  },
  endurance: {
    label: 'Rezistență / progres măsurabil', sports: ['athletics', 'cycling', 'rowing', 'triathlon', 'canoe', 'cross-country-skiing', 'biathlon', 'speed-skating', 'short-track', 'aquatics'],
    angle: 'progres măsurabil, rezistență, rutină, date, recuperare și disciplină zilnică',
    sponsors: 'echipament, nutriție, ceasuri sport, clinici, branduri de sănătate, companii locale',
    products: 'planuri de antrenament, challenge-uri, coaching, newsletter, campanii de susținere pentru competiții',
    content: ['grafic de progres', 'antrenament de bază', 'recuperare și nutriție']
  },
  team: {
    label: 'Sport de echipă', sports: ['football', 'basketball', 'handball', 'volleyball', 'hockey', 'ice-hockey', 'rugby-sevens', 'flag-football', 'baseball-softball', 'cricket', 'lacrosse'],
    angle: 'echipă, leadership, energie de grup, comunitate și momente video spectaculoase',
    sponsors: 'branduri locale, restaurante, echipament, streetwear, săli, educație sportivă, evenimente',
    products: 'campuri, antrenamente private, merch, academii pentru copii, evenimente demonstrative',
    content: ['moment de joc', 'vestiar și echipă', 'highlight cu explicație tactică']
  },
  precision: {
    label: 'Precizie / concentrare', sports: ['archery', 'shooting', 'golf', 'curling'],
    angle: 'calm, precizie, concentrare, tehnică fină și control sub presiune',
    sponsors: 'branduri premium, echipament tehnic, educație, servicii financiare, clinici, companii locale',
    products: 'clinicuri, workshopuri corporate, sesiuni de concentrare, demonstrații, conținut educativ',
    content: ['ritual înainte de execuție', 'detaliu tehnic', 'explicație despre presiune']
  },
  aesthetic: {
    label: 'Vizual / expresiv', sports: ['gymnastics', 'figure-skating', 'equestrian', 'skateboarding', 'sport-climbing', 'surfing', 'snowboard', 'freestyle-skiing'],
    angle: 'estetică, risc, control corporal, expresie vizuală și poveste cinematografică',
    sponsors: 'fashion, beauty, wellness, echipament, foto-video, lifestyle, turism, branduri pentru tineri',
    products: 'workshopuri, tutoriale, spectacole, apariții la evenimente, cursuri online, merch vizual',
    content: ['mișcare spectaculoasă', 'slow motion', 'înainte/după execuție']
  },
  racket: {
    label: 'Rachetă / reflex', sports: ['tennis', 'table-tennis', 'badminton', 'squash'],
    angle: 'viteză, reflex, duel mental, eleganță, tehnică și decizie în fracțiuni de secundă',
    sponsors: 'cluburi, echipament, educație privată, branduri premium, clinici, academii pentru copii',
    products: 'lecții private, clinicuri, tabere, mini-cursuri video, sesiuni corporate',
    content: ['exercițiu de reflex', 'punct spectaculos', 'sfat tehnic scurt']
  },
  strength: {
    label: 'Forță / explozie', sports: ['weightlifting', 'bobsleigh', 'skeleton', 'luge'],
    angle: 'forță, explozie, risc, pregătire invizibilă și performanță în câteva secunde decisive',
    sponsors: 'săli, recuperare, echipament, nutriție, branduri de performanță, companii industriale',
    products: 'programe de forță, seminarii, sesiuni de tehnică, conținut premium, campanii de susținere',
    content: ['ridicare/plecare explozivă', 'pregătire fizică', 'detaliu despre tehnică și siguranță']
  },
  outdoor: {
    label: 'Outdoor / aventură', sports: ['sailing', 'alpine-skiing', 'ski-jumping', 'nordic-combined', 'modern-pentathlon'],
    angle: 'natură, curaj, tehnică, strategie și adaptare la condiții schimbătoare',
    sponsors: 'turism, outdoor, echipament tehnic, transport, wellness, branduri premium locale',
    products: 'experiențe, workshopuri, tabere, ghiduri, campanii de susținere pentru deplasări',
    content: ['cadru larg în mediul sportului', 'pregătirea echipamentului', 'explicație despre risc și strategie']
  }
};

window.SBAI.labels = Object.fromEntries(window.SBAI.olympicSports.flatMap(g => g.items));
