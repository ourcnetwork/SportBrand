'use strict';

/* Colectare date în Google Sheets.
   Aplicația e statică — nu are server propriu. „Backend-ul" e un Google Apps
   Script publicat ca Web App (vezi google-apps-script.gs). Trimitem un POST
   simplu (text/plain, mode:'no-cors') ca să evităm preflight CORS și să
   funcționeze inclusiv din găzduire statică.

   ONEST: 'no-cors' înseamnă „trimite și uită" — browserul nu ne lasă să citim
   răspunsul, deci nu putem confirma 100% că rândul a fost scris. Pentru
   confirmare reală (și validare, anti-spam) ai nevoie de un backend propriu.
   Din file:// unele browsere pot bloca cererea; publică aplicația pe un host
   (ex. GitHub Pages) pentru colectare fiabilă. */

window.SBAI = window.SBAI || {};

(function collect() {
  const sb = window.SBAI;

  function endpoint() {
    const c = sb.config && sb.config.collect;
    return c && typeof c.sheetsEndpoint === 'string' ? c.sheetsEndpoint.trim() : '';
  }

  function isEnabled() {
    return endpoint().length > 0;
  }

  // Trimite un obiect plat către Sheets. Nereușita nu blochează UX-ul.
  async function send(type, payload) {
    const url = endpoint();
    if (!url) return { ok: false, reason: 'disabled' };

    const body = JSON.stringify({
      type: type || 'lead',
      sentAt: new Date().toISOString(),
      page: (typeof location !== 'undefined' ? location.href : ''),
      ...payload
    });

    try {
      await fetch(url, {
        method: 'POST',
        mode: 'no-cors',
        // text/plain evită preflight-ul CORS; Apps Script citește e.postData.contents
        headers: { 'Content-Type': 'text/plain;charset=utf-8' },
        body
      });
      return { ok: true };
    } catch (e) {
      return { ok: false, reason: 'network' };
    }
  }

  // Construiește un rând standard dintr-un profil + scor.
  function rowFromProfile(data, sc) {
    return {
      name: data.name || '',
      sport: sb.label ? sb.label(data.sport) : data.sport,
      level: data.level || '',
      goal: data.goal || '',
      city: data.city || '',
      followers: data.followers || 0,
      score: sc ? sc.total : '',
      valueLow: sc && sc.value ? sc.value.low : '',
      valueHigh: sc && sc.value ? sc.value.high : '',
      contactEmail: data.contactEmail || '',
      contactPhone: data.contactPhone || ''
    };
  }

  sb.collect = { send, isEnabled, rowFromProfile };
})();
