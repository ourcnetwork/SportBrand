'use strict';

/* Client pentru „backend-ul" Apps Script.
   Două tipuri de apel, alese pe baza restricțiilor de browser:

   - CITIRI (validare cod, citire pagină, statistici): GET cu parametri în URL.
     Apps Script răspunde cu un redirect către script.googleusercontent.com,
     care servește conținutul cu CORS permisiv — deci putem CITI răspunsul.

   - SCRIERI (salvare pagină, log vizualizare/click, lead): POST 'no-cors',
     „trimite și uită" (nu putem citi răspunsul, dar scrierea se face).

   Totul e activ doar dacă există un endpoint configurat; altfel fiecare
   funcție întoarce {ok:false, reason:'disabled'} și aplicația cade elegant
   pe varianta statică. */

window.SBAI = window.SBAI || {};

(function api() {
  const sb = window.SBAI;

  function endpoint() {
    const c = sb.config && sb.config.collect;
    return c && typeof c.sheetsEndpoint === 'string' ? c.sheetsEndpoint.trim() : '';
  }
  function enabled() { return endpoint().length > 0; }

  function flag(name) {
    const b = sb.config && sb.config.backend;
    return enabled() && b && b[name] !== false;
  }

  function buildUrl(action, params) {
    const base = endpoint();
    const usp = new URLSearchParams({ action: action });
    Object.keys(params || {}).forEach((k) => {
      if (params[k] != null) usp.set(k, String(params[k]));
    });
    return `${base}${base.indexOf('?') >= 0 ? '&' : '?'}${usp.toString()}`;
  }

  // Citire cu răspuns JSON.
  async function get(action, params) {
    if (!enabled()) return { ok: false, reason: 'disabled' };
    try {
      const res = await fetch(buildUrl(action, params), { method: 'GET', redirect: 'follow' });
      const text = await res.text();
      let data;
      try { data = JSON.parse(text); } catch (_) { return { ok: false, reason: 'badjson' }; }
      return { ok: true, data };
    } catch (e) {
      return { ok: false, reason: 'network' };
    }
  }

  // Scriere „trimite și uită".
  async function post(action, payload) {
    if (!enabled()) return { ok: false, reason: 'disabled' };
    const body = JSON.stringify({ action, sentAt: new Date().toISOString(), ...payload });
    try {
      await fetch(endpoint(), {
        method: 'POST', mode: 'no-cors',
        headers: { 'Content-Type': 'text/plain;charset=utf-8' },
        body
      });
      return { ok: true };
    } catch (e) {
      return { ok: false, reason: 'network' };
    }
  }

  // --- API de nivel înalt ---
  async function validateCode(code, email) {
    const r = await get('validate', { code, email });
    return r.ok && r.data && r.data.valid === true;
  }
  function savePage(id, payload) {
    return post('savepage', { id, payload: JSON.stringify(payload) });
  }
  async function getPage(id) {
    const r = await get('page', { id });
    if (!r.ok || !r.data || !r.data.payload) return null;
    try { return JSON.parse(r.data.payload); } catch (_) { return null; }
  }
  function logEvent(id, type) {
    return post(type === 'click' ? 'logclick' : 'logview', { id });
  }
  async function getStats(id) {
    const r = await get('stats', { id });
    if (!r.ok || !r.data) return null;
    return { views: Number(r.data.views) || 0, clicks: Number(r.data.clicks) || 0 };
  }

  // --- Consola operatorului ---
  async function adminSummary(key) {
    const r = await get('admin_summary', { key });
    return r.ok && r.data && r.data.ok ? r.data : null;
  }
  async function adminPages(key) {
    const r = await get('admin_pages', { key });
    return r.ok && r.data && r.data.ok ? r.data.pages : null;
  }
  async function adminLeads(key, limit) {
    const r = await get('admin_leads', { key, limit: limit || 25 });
    return r.ok && r.data && r.data.ok ? r.data.leads : null;
  }

  // --- Generare AI (prin backend; cheia stă în Script Properties) ---
  // kind: 'strategy' | 'brand' | 'outreach'
  async function aiGenerate(kind, data, sc) {
    const profile = {
      name: data.name, sport: sb.label ? sb.label(data.sport) : data.sport,
      level: data.level, goal: data.goal, city: data.city,
      audience: data.audience, tone: data.tone,
      results: data.results, assets: data.assets, followers: data.followers,
      score: sc ? sc.total : '', weakest: sc && sc.weakest ? sc.weakest.label : ''
    };
    const r = await get('ai', { kind, profile: JSON.stringify(profile) });
    if (!r.ok || !r.data) return { ok: false, error: 'network' };
    if (r.data.ok && r.data.text) return { ok: true, text: String(r.data.text) };
    return { ok: false, error: r.data.error || 'unknown' };
  }

  sb.api = {
    enabled, flag, get, post,
    validateCode, savePage, getPage, logEvent, getStats,
    adminSummary, adminPages, adminLeads, aiGenerate
  };
})();
