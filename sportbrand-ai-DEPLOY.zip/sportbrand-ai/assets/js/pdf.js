'use strict';

/* Meta-date pentru coperta și executive brief-ul PDF-ului. */

window.SBAI = window.SBAI || {};

window.SBAI.updatePdfMeta = function updatePdfMeta(data, score, sc) {
  const sb = window.SBAI;
  const set = (id, value) => { const el = document.getElementById(id); if (el) el.textContent = value; };

  set('pdfTitle', `Strategie premium pentru ${data.name}`);
  set('pdfName', data.name);
  set('pdfSport', sb.label(data.sport));
  set('pdfGoal', sb.goalText(data.goal));
  set('pdfScore', `${score}/100`);
  set('pdfPlan', sb.isPremium() ? 'PREMIUM' : 'FREE');
  set('pdfDate', sb.format.dateLong());

  set('pdfExecName', data.name);
  set('pdfExecSport', sb.label(data.sport));
  set('pdfExecGoal', sb.goalText(data.goal));
  set('pdfExecScore', `${score}/100`);

  const sport = sb.label(data.sport);
  const city = data.city || 'piața locală';
  const valueBit = sc && sc.value
    ? ` Valoarea estimată a unui parteneriat este ${sb.format.lei(sc.value.low)}–${sb.format.lei(sc.value.high)}/lună.`
    : '';
  const recommendation = sb.isPremium()
    ? `Poziționează sportivul ca activ de comunicare locală în ${city}, apoi folosește media kit-ul, calendarul de 30 de zile și pachetele Bronze/Silver/Gold pentru contactarea sponsorilor potriviți din zona ${sport}.${valueBit}`
    : `Raportul FREE oferă direcția inițială. Pentru ${sport}, următorul pas comercial este activarea raportului premium, astfel încât sportivul să primească media kit, calendar, pitch sponsor și pachete de ofertare.`;
  set('pdfExecRecommendation', recommendation);
};
