'use strict';

/* PWA: înregistrare service worker, buton de instalare, stare offline.

   NOTE:
   - Service worker-ul funcționează doar pe HTTPS (sau localhost). Din file://
     nu se înregistrează — aplicația merge normal, doar fără offline/instalare.
   - Pe Android/desktop apare promptul de instalare (beforeinstallprompt).
     Pe iOS nu există acest eveniment: acolo afișăm instrucțiunea manuală
     (Share → Add to Home Screen). */

window.SBAI = window.SBAI || {};

(function pwa() {
  const sb = window.SBAI;
  let deferredPrompt = null;

  function isStandalone() {
    return window.matchMedia('(display-mode: standalone)').matches ||
           window.navigator.standalone === true;
  }
  function isIOS() {
    return /iphone|ipad|ipod/i.test(window.navigator.userAgent);
  }

  function btn() { return document.getElementById('installBtn'); }

  function showInstallButton() {
    const b = btn();
    if (b) b.style.display = '';
  }
  function hideInstallButton() {
    const b = btn();
    if (b) b.style.display = 'none';
  }

  // --- Service worker ---
  function registerSW() {
    if (!('serviceWorker' in navigator)) return;
    if (window.location.protocol === 'file:') return; // nu merge din file://

    navigator.serviceWorker.register('sw.js').then((reg) => {
      // Anunță utilizatorul când e disponibilă o versiune nouă.
      reg.addEventListener('updatefound', () => {
        const nw = reg.installing;
        if (!nw) return;
        nw.addEventListener('statechange', () => {
          if (nw.state === 'installed' && navigator.serviceWorker.controller) {
            if (sb.showToast) sb.showToast('Versiune nouă disponibilă — reîncarcă pagina.');
          }
        });
      });
    }).catch(() => { /* înregistrarea a eșuat: aplicația merge oricum */ });
  }

  // --- Instalare ---
  function bindInstall() {
    window.addEventListener('beforeinstallprompt', (e) => {
      e.preventDefault();
      deferredPrompt = e;
      if (!isStandalone()) showInstallButton();
    });

    window.addEventListener('appinstalled', () => {
      deferredPrompt = null;
      hideInstallButton();
      if (sb.showToast) sb.showToast('SportBrand AI a fost instalat pe dispozitiv.');
    });

    const b = btn();
    if (!b) return;

    b.addEventListener('click', async () => {
      if (deferredPrompt) {
        deferredPrompt.prompt();
        try { await deferredPrompt.userChoice; } catch (_) {}
        deferredPrompt = null;
        hideInstallButton();
        return;
      }
      if (isIOS() && sb.showToast) {
        sb.showToast('Pe iPhone: apasă „Share" (□↑), apoi „Add to Home Screen".');
      }
    });

    // iOS nu emite beforeinstallprompt: arătăm butonul cu instrucțiunea manuală.
    if (isIOS() && !isStandalone()) showInstallButton();
  }

  // --- Stare offline ---
  function bindOffline() {
    window.addEventListener('offline', () => {
      if (sb.showToast) sb.showToast('Ești offline. Scorul, simulatorul și rosterul funcționează normal.');
    });
    window.addEventListener('online', () => {
      if (sb.showToast) sb.showToast('Conexiune restabilită.');
    });
  }

  function init() {
    registerSW();
    bindInstall();
    bindOffline();
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', init);
  } else {
    init();
  }

  sb.pwa = { isStandalone, isIOS };
})();
