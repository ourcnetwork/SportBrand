/**
 * SportBrand AI — backend pe Google Apps Script
 * =============================================
 * Un singur Web App acoperă tot: colectare lead-uri, validare coduri premium,
 * linkuri scurte pentru Pagina Live și analytics (vizualizări + click-uri).
 *
 * INSTALARE (o singură dată):
 * 1. sheets.google.com → Spreadsheet nou → Extensions → Apps Script.
 * 2. Șterge tot și lipește acest fișier.
 * 3. Deploy → New deployment → tip „Web app”
 *      - Execute as: Me
 *      - Who has access: Anyone
 *    Copiază URL-ul „Web app” (se termină în /exec).
 * 4. Pune URL-ul în assets/js/config.js → collect.sheetsEndpoint.
 *
 * FILE folosite (se creează automat):
 *   - Leads     : comenzile și profilurile trimise din aplicație
 *   - Codes     : coduri premium. Coloane: code | note | active
 *                 (adaugi un rând cu codul → devine valid; active=FALSE îl dezactivează)
 *   - Pages     : paginile live. Coloane: id | payload | updatedAt
 *   - Stats     : analytics. Coloane: id | views | clicks | lastAt
 *
 * Note: cererile de citire (validate/page/stats) răspund cu JSON și pot fi
 * citite de aplicație. Scrierile (savepage/logview/logclick/lead) vin ca POST.
 */

var SHEETS = { leads: 'Leads', codes: 'Codes', pages: 'Pages', stats: 'Stats' };

/* CHEIA DE ADMIN pentru consola operatorului (admin.html).
   Schimb-o înainte de deploy! Stă doar aici, în sursa Apps Script — vizitatorii
   site-ului nu o pot vedea. NOTĂ: cheia circulă ca parametru de URL, deci poate
   apărea în log-uri; e potrivită pentru un singur operator, nu pentru date
   sensibile sau echipe mari. */
var ADMIN_KEY = 'schimba-cheia-asta';

var LEAD_COLUMNS = [
  'sentAt', 'type', 'name', 'clientName', 'clientEmail', 'clientPhone',
  'package', 'sport', 'level', 'goal', 'city', 'followers',
  'score', 'valueLow', 'valueHigh', 'contactEmail', 'contactPhone', 'notes', 'page'
];

/* ---------- Routing ---------- */

function doGet(e) {
  var p = (e && e.parameter) || {};
  var action = p.action || 'ping';
  try {
    if (action === 'validate') return json_({ valid: isCodeValid_(p.code, p.email) });
    if (action === 'page')     return json_(getPage_(p.id));
    if (action === 'stats')    return json_(getStats_(p.id));
    if (action === 'ai')       return json_(aiGenerate_(p));
    if (action.indexOf('admin_') === 0) {
      if (String(p.key || '') !== ADMIN_KEY) return json_({ ok: false, error: 'unauthorized' });
      if (action === 'admin_summary') return json_(adminSummary_());
      if (action === 'admin_pages')   return json_(adminPages_());
      if (action === 'admin_leads')   return json_(adminLeads_(Number(p.limit) || 25));
      return json_({ ok: false, error: 'unknown admin action' });
    }
    return json_({ ok: true, service: 'SportBrand AI backend', time: new Date().toISOString() });
  } catch (err) {
    return json_({ ok: false, error: String(err) });
  }
}

function doPost(e) {
  var data = {};
  try {
    if (e && e.postData && e.postData.contents) data = JSON.parse(e.postData.contents);
  } catch (err) {
    return json_({ ok: false, error: 'bad json' });
  }
  var action = data.action || 'lead';
  var lock = LockService.getScriptLock();
  try {
    lock.waitLock(20000);
    if (action === 'savepage')      savePage_(data);
    else if (action === 'logview')  bumpStat_(data.id, 'views');
    else if (action === 'logclick') bumpStat_(data.id, 'clicks');
    else                            appendLead_(data);
    return json_({ ok: true });
  } catch (err) {
    return json_({ ok: false, error: String(err) });
  } finally {
    try { lock.releaseLock(); } catch (e2) {}
  }
}

/* ---------- Leads ---------- */

function appendLead_(data) {
  var sheet = sheet_(SHEETS.leads);
  if (sheet.getLastRow() === 0) sheet.appendRow(LEAD_COLUMNS);
  sheet.appendRow(LEAD_COLUMNS.map(function (k) {
    var v = data[k];
    return (v === undefined || v === null) ? '' : v;
  }));
}

/* ---------- Coduri premium ---------- */

function isCodeValid_(code, email) {
  code = String(code || '').trim();
  if (!code) return false;
  var sheet = sheet_(SHEETS.codes);
  if (sheet.getLastRow() === 0) {
    sheet.appendRow(['code', 'note', 'active']);
    return false;
  }
  var values = sheet.getDataRange().getValues();
  for (var i = 1; i < values.length; i++) {
    var rowCode = String(values[i][0] || '').trim();
    var active = values[i][2];
    if (rowCode && rowCode === code) {
      // active gol sau TRUE => valid; FALSE/0/"nu" => invalid
      if (active === false || String(active).toLowerCase() === 'false' || String(active) === '0') return false;
      return true;
    }
  }
  return false;
}

/* ---------- Pagini live (linkuri scurte) ---------- */

function savePage_(data) {
  var id = String(data.id || '').trim();
  if (!id) throw new Error('missing id');
  var payload = String(data.payload || '');
  var sheet = sheet_(SHEETS.pages);
  if (sheet.getLastRow() === 0) sheet.appendRow(['id', 'payload', 'updatedAt']);
  var values = sheet.getDataRange().getValues();
  var now = new Date().toISOString();
  for (var i = 1; i < values.length; i++) {
    if (String(values[i][0]) === id) {
      sheet.getRange(i + 1, 2).setValue(payload);
      sheet.getRange(i + 1, 3).setValue(now);
      return;
    }
  }
  sheet.appendRow([id, payload, now]);
}

function getPage_(id) {
  id = String(id || '').trim();
  if (!id) return { ok: false };
  var sheet = sheet_(SHEETS.pages);
  if (sheet.getLastRow() === 0) return { ok: false };
  var values = sheet.getDataRange().getValues();
  for (var i = 1; i < values.length; i++) {
    if (String(values[i][0]) === id) return { ok: true, payload: values[i][1] };
  }
  return { ok: false };
}

/* ---------- Analytics ---------- */

function bumpStat_(id, field) {
  id = String(id || '').trim();
  if (!id) return;
  var sheet = sheet_(SHEETS.stats);
  if (sheet.getLastRow() === 0) sheet.appendRow(['id', 'views', 'clicks', 'lastAt']);
  var values = sheet.getDataRange().getValues();
  var now = new Date().toISOString();
  var col = field === 'clicks' ? 3 : 2;
  for (var i = 1; i < values.length; i++) {
    if (String(values[i][0]) === id) {
      var cur = Number(values[i][col - 1]) || 0;
      sheet.getRange(i + 1, col).setValue(cur + 1);
      sheet.getRange(i + 1, 4).setValue(now);
      return;
    }
  }
  var row = [id, 0, 0, now];
  row[col - 1] = 1;
  sheet.appendRow(row);
}

function getStats_(id) {
  id = String(id || '').trim();
  var out = { views: 0, clicks: 0 };
  if (!id) return out;
  var sheet = sheet_(SHEETS.stats);
  if (sheet.getLastRow() === 0) return out;
  var values = sheet.getDataRange().getValues();
  for (var i = 1; i < values.length; i++) {
    if (String(values[i][0]) === id) {
      out.views = Number(values[i][1]) || 0;
      out.clicks = Number(values[i][2]) || 0;
      return out;
    }
  }
  return out;
}

/* ---------- Consola operatorului (admin) ---------- */

function adminSummary_() {
  var leads = rows_(SHEETS.leads);
  var pages = rows_(SHEETS.pages);
  var stats = rows_(SHEETS.stats);
  var codes = rows_(SHEETS.codes);

  var totalViews = 0, totalClicks = 0;
  for (var i = 0; i < stats.length; i++) {
    totalViews += Number(stats[i][1]) || 0;
    totalClicks += Number(stats[i][2]) || 0;
  }
  var orders = 0;
  for (var j = 0; j < leads.length; j++) {
    if (String(leads[j][1]) === 'order') orders++;
  }
  var activeCodes = 0;
  for (var k = 0; k < codes.length; k++) {
    var a = codes[k][2];
    if (!(a === false || String(a).toLowerCase() === 'false' || String(a) === '0')) activeCodes++;
  }
  return {
    ok: true, leads: leads.length, orders: orders, pages: pages.length,
    views: totalViews, clicks: totalClicks, activeCodes: activeCodes
  };
}

// Paginile live + statisticile lor, unite pe id, sortate după click-uri apoi vizualizări.
function adminPages_() {
  var pages = rows_(SHEETS.pages);
  var stats = rows_(SHEETS.stats);
  var statById = {};
  for (var i = 0; i < stats.length; i++) {
    statById[String(stats[i][0])] = { views: Number(stats[i][1]) || 0, clicks: Number(stats[i][2]) || 0, lastAt: stats[i][3] || '' };
  }
  var out = [];
  for (var j = 0; j < pages.length; j++) {
    var id = String(pages[j][0]);
    var name = '', score = '';
    try {
      var payload = JSON.parse(pages[j][1]);
      name = payload.name || '';
      score = payload.score != null ? payload.score : '';
    } catch (e) { /* payload corupt: afișăm doar id */ }
    var st = statById[id] || { views: 0, clicks: 0, lastAt: '' };
    out.push({ id: id, name: name, score: score, views: st.views, clicks: st.clicks, lastAt: st.lastAt, updatedAt: pages[j][2] || '' });
  }
  out.sort(function (a, b) { return (b.clicks - a.clicks) || (b.views - a.views); });
  return { ok: true, pages: out };
}

// Ultimele lead-uri/comenzi (cele mai noi primele).
function adminLeads_(limit) {
  var leads = rows_(SHEETS.leads);
  var out = [];
  for (var i = leads.length - 1; i >= 0 && out.length < limit; i--) {
    var r = leads[i];
    out.push({
      sentAt: r[0] || '', type: r[1] || '', name: r[2] || '', clientName: r[3] || '',
      clientEmail: r[4] || '', clientPhone: r[5] || '', packageName: r[6] || '',
      sport: r[7] || '', score: r[12] || ''
    });
  }
  return { ok: true, leads: out };
}

// Rândurile unei foi, fără antet.
function rows_(name) {
  var sheet = sheet_(name);
  if (sheet.getLastRow() <= 1) return [];
  return sheet.getDataRange().getValues().slice(1);
}

/* ---------- Generare AI (Gemini) ---------- */

/* Cheia NU stă în cod. O pui o singură dată în Script Properties:
   Apps Script → Project Settings → Script properties → Add property:
     GEMINI_API_KEY = cheia ta (gratuită, de la https://aistudio.google.com/apikey)
   Fără cheie, endpoint-ul răspunde {ok:false, error:'no_key'} iar aplicația
   rămâne pe template-uri. */

var AI_MODEL = 'gemini-2.0-flash';

function aiGenerate_(p) {
  var key = PropertiesService.getScriptProperties().getProperty('GEMINI_API_KEY');
  if (!key) return { ok: false, error: 'no_key' };

  var profile = {};
  try { profile = JSON.parse(p.profile || '{}'); } catch (e) { return { ok: false, error: 'bad_profile' }; }
  var prompt = buildPrompt_(String(p.kind || ''), profile);
  if (!prompt) return { ok: false, error: 'bad_kind' };

  var url = 'https://generativelanguage.googleapis.com/v1beta/models/' + AI_MODEL + ':generateContent?key=' + encodeURIComponent(key);
  var res = UrlFetchApp.fetch(url, {
    method: 'post',
    contentType: 'application/json',
    payload: JSON.stringify({
      contents: [{ parts: [{ text: prompt }] }],
      generationConfig: { temperature: 0.7, maxOutputTokens: 900 }
    }),
    muteHttpExceptions: true
  });
  if (res.getResponseCode() !== 200) return { ok: false, error: 'model_' + res.getResponseCode() };

  var body = JSON.parse(res.getContentText());
  var text = '';
  try { text = body.candidates[0].content.parts[0].text || ''; } catch (e2) {}
  if (!text) return { ok: false, error: 'empty' };
  return { ok: true, text: text };
}

function buildPrompt_(kind, d) {
  var base = 'Ești consultant de marketing sportiv pentru piața din România. ' +
    'Scrie în română, natural și concret, fără introduceri despre tine, fără Markdown (fără asteriscuri sau diezuri), text simplu cu liniuțe unde e cazul.\n\n' +
    'Profilul sportivului:\n' +
    '- Nume: ' + (d.name || '-') + '\n' +
    '- Sport: ' + (d.sport || '-') + ' · Nivel: ' + (d.level || '-') + ' · Oraș: ' + (d.city || '-') + '\n' +
    '- Obiectiv: ' + (d.goal || '-') + ' · Public: ' + (d.audience || '-') + ' · Ton dorit: ' + (d.tone || '-') + '\n' +
    '- Rezultate: ' + (d.results || '-') + '\n' +
    '- Urmăritori social media: ' + (d.followers || 0) + '\n' +
    '- Ce poate oferi sponsorilor: ' + (d.assets || '-') + '\n' +
    '- Scor comercial calculat: ' + (d.score || '-') + '/100' +
    (d.weakest ? ' · Punct slab: ' + d.weakest : '') + '\n\n';

  if (kind === 'strategy') {
    return base + 'Scrie o strategie de promovare personalizată (200-280 de cuvinte): poziționarea potrivită acestui profil, 3 direcții concrete de acțiune prioritizate după punctul slab, și cum ar trebui abordați sponsorii din categoria potrivită sportului. Termină cu pasul cel mai important pentru următoarele 2 săptămâni.';
  }
  if (kind === 'brand') {
    return base + 'Scrie poziționarea de brand personal (150-200 de cuvinte): o propoziție de poziționare memorabilă, mesajul central în tonul cerut, 3 teme de conținut care îl diferențiază, și o scurtă biografie de 2-3 propoziții pentru media kit, la persoana a treia.';
  }
  if (kind === 'outreach') {
    return base + 'Scrie un email de prezentare către un potențial sponsor local potrivit acestui sport (max 170 de cuvinte): subiect propus pe prima linie (prefixat cu "Subiect:"), apoi corpul. Concret, orientat pe beneficiul sponsorului (vizibilitate, asociere cu performanța, acces la public), cu o cerere clară de întâlnire de 15 minute. Fără platitudini.';
  }
  return '';
}

/* ---------- Utilitare ---------- */

function sheet_(name) {
  var ss = SpreadsheetApp.getActiveSpreadsheet();
  return ss.getSheetByName(name) || ss.insertSheet(name);
}

function json_(obj) {
  return ContentService
    .createTextOutput(JSON.stringify(obj))
    .setMimeType(ContentService.MimeType.JSON);
}
