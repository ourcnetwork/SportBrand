# SportBrand AI

MVP web static pentru sportivi, cluburi și academii. Generează scor comercial, strategie de promovare, brand personal, conținut, calendar, media kit, sponsor outreach, pachete de sponsorizare și PDF premium.

Aplicația e **statică** (HTML + CSS + JS vanilla, fără build, fără server). O deschizi direct: `index.html`.

> **Vrei s-o publici?** Citește **[LANSARE.md](LANSARE.md)** — manual pas-cu-pas, de la fișiere la URL public, în ~30 de minute. Scriptul `setup.py` îți setează domeniul și backend-ul dintr-o comandă.

## Aplicație instalabilă / PWA (nou)

Publicată pe HTTPS, aplicația se comportă ca o aplicație nativă:

- **Instalabilă pe telefon** — pe Android/Chrome apare butonul „Instalează aplicația" în meniul lateral (plus promptul nativ). Pe iOS: Share (□↑) → Add to Home Screen. Pornește full-screen, cu iconiță proprie.
- **Funcționează offline** — după prima vizită, scorul, simulatorul, raportul, rosterul și exportul PDF merg fără internet (totul e calculat local). Doar AI-ul, linkurile scurte și analytics cer conexiune.
- Fișiere: `manifest.webmanifest`, `sw.js` (service worker), `assets/js/pwa.js`, plus iconițele din `assets/img/`.

**Strategia de cache, aleasă intenționat:** *network-first* pe HTML (deci utilizatorii nu rămân blocați pe versiuni vechi când au net) și *cache-first* pe CSS/JS/imagini, versionat prin `CACHE_VERSION` din `sw.js`. Apelurile către backend nu sunt niciodată servite din cache.

> ⚠️ **La fiecare release**, incrementează `CACHE_VERSION` în `sw.js` (`'v1'` → `'v2'`), altfel utilizatorii care au instalat aplicația pot rămâne cu fișiere vechi.
>
> Service worker-ul **nu funcționează din `file://`** — cere HTTPS (sau `localhost`). Pentru test local: `python3 -m http.server 8000`.

## Generare AI reală (nou, opțional — cere backend-ul)

Numele produsului își onorează în sfârșit „AI"-ul: secțiunile care contează pot fi rescrise de un model live (Gemini), personalizat pe profilul concret, nu pe template.

- **Unde:** butoane „✦ Rescrie cu AI" pe **Strategie**, **Brand personal** și **Sponsor Outreach** (email) — vizibile doar cu premium activ și backend configurat.
- **Ce primește modelul:** sportul, nivelul, rezultatele, orașul, publicul, tonul ales, oferta pentru sponsori, scorul calculat și punctul slab — deci strategia vorbește despre profilul real, iar emailul e scris pentru categoria de sponsori potrivită sportului.
- **Cheia API nu e niciodată în client.** Stă în Apps Script → Project Settings → **Script properties**: adaugi `GEMINI_API_KEY` = cheia ta (gratuită, de la aistudio.google.com/apikey) și re-publici deploy-ul. Fără cheie, butonul explică exact ce lipsește; fără backend, butoanele nu apar deloc — totul cade pe template-uri.
- Textul generat e marcat vizibil „✦ GENERAT CU AI — verifică înainte de trimitere" și intră apoi normal în copiere/salvare/PDF.

**Onest despre limite:** o generare durează 2–5 secunde (Apps Script + model); free tier-ul Gemini are cote (potrivit pentru zeci de generări pe zi, nu sute); calitatea variază — textul AI trebuie citit de un om înainte să plece la un sponsor real. Integrarea am testat-o cu răspunsuri simulate pe ambele capete; confirm-o cu cheia ta pe un deploy real.

## Consola operatorului (nou, opțional — cere backend-ul)

`admin.html` e un dashboard privat pentru operator/club, peste datele colectate de backend:

- **Rezumat**: comenzi primite, lead-uri totale, coduri premium active, pagini live, vizualizări totale și click-uri „Contact".
- **Pagini live · interes sponsori**: toți sportivii cu pagină live, sortați după click-uri pe „Contactează pentru parteneriat" (semnalul cald de vânzare), apoi după vizualizări, cu link direct de deschidere. Un click pe „Contact" = momentul potrivit să suni atletul și să-i propui pachetul premium.
- **Ultimele comenzi și lead-uri**: cine a comandat, ce pachet, cu ce contact — comenzile care așteaptă cod se gestionează din fila „Codes".

**Acces:** setează `ADMIN_KEY` în `google-apps-script.gs` (schimbă valoarea implicită!) și re-publică deploy-ul. Deschizi `admin.html`, introduci cheia — se verifică **pe server** și se ține minte în browserul tău.

**Onest despre securitate:** cheia stă în sursa Apps Script (invizibilă vizitatorilor site-ului), ceea ce e mai bine decât o cheie în JavaScript-ul public — dar circulă ca parametru de URL (poate apărea în log-uri) și nu există utilizatori/sesiuni/permisiuni. E o barieră potrivită pentru un singur operator, nu autentificare reală. Consola citește foile întregi la fiecare încărcare — pe volume mari devine lentă (Apps Script: ~1–2s/cerere + cote zilnice). Pentru echipe sau date sensibile: backend propriu cu autentificare reală.

## Backend pe Google Apps Script (nou, opțional)

Aplicația rămâne statică, dar același Google Apps Script care colectează comenzile poate funcționa ca un mic **backend gratuit**, găzduit de Google. Activezi tot dintr-un singur loc: pui URL-ul Web App în `assets/js/config.js → collect.sheetsEndpoint`. Fără el, aplicația e 100% statică (fallback automat).

**Instalare:** creează un Spreadsheet → `Extensions → Apps Script` → lipește `google-apps-script.gs` → `Deploy → New deployment → Web app` (Execute as: Me · Who has access: Anyone) → copiază URL-ul `/exec` în config.

Ce deblochează (fiecare cu comutator în `config.backend`):

- **Coduri premium validate pe server** (`serverCodes`). Codurile nu mai pot fi verificate din sursa clientului. Le gestionezi într-o filă „Codes" din Spreadsheet: adaugi un rând cu codul → devine valid; pui `active = FALSE` → îl dezactivezi. Aplicația întreabă serverul la activare. Codul demo rămâne valabil local pentru testare.
- **Linkuri scurte pentru Pagina Live** (`shortLinks`). În loc de un URL de ~1.700 de caractere, pagina se salvează pe backend cu un ID scurt, determinist per atlet: linkul devine `brand.html?p=ID` — scurt, permanent și **editabil** (regenerezi profilul → același link arată versiunea nouă).
- **Analytics real** (`analytics`). Fiecare deschidere a Paginii Live și fiecare click pe „Contactează pentru parteneriat" incrementează un contor pe server. În panoul „Pagina Live" vezi câte vizualizări și click-uri a primit linkul.

File create automat în Spreadsheet: `Leads` (comenzi), `Codes` (coduri premium), `Pages` (paginile live), `Stats` (analytics).

Fiecare comandă trimisă adaugă un rând în `Leads` (dată, client, contact, pachet, sport, scor, valoare estimată). Setează `collect.sendOnGenerate: true` dacă vrei să colectezi și profilurile generate, nu doar comenzile.

**Onest despre plafonul acestui backend:** Apps Script e lent (~1–2s pe cerere), URL-urile Google sunt lungi/urâte, are cote zilnice de utilizare și rămâne nepotrivit pentru plăți automate sau generare AI live. Scrierile (salvare pagină, log vizualizare/click, comandă) sunt „fire-and-forget" — din motive de securitate a browserului aplicația nu poate confirma 100% scrierea. E un backend serios de MVP, nu de producție la scară. Pentru confirmări reale, plăți și AI ai nevoie de un backend propriu.

## SEO (nou)

`index.html` include acum titlu și descriere optimizate, `canonical`, `robots`, Open Graph complet (cu imagine socială `assets/img/og-cover.png`, 1200×630), Twitter Cards și date structurate JSON-LD (`SoftwareApplication` cu prețuri). Am adăugat și `robots.txt` și `sitemap.xml`.

**Important înainte de publicare:** înlocuiește peste tot `https://REPLACE-CU-DOMENIUL-TAU` cu domeniul real (apare în `index.html`, `robots.txt` și `sitemap.xml`). Fără domeniul corect, `canonical`, `og:url` și imaginea socială nu funcționează cum trebuie. Fonturile Google rămân o dependență externă; pentru un scor de performanță mai bun le poți găzdui local.

## Pagini informative și legale (nou)

Pe lângă cele 5 pagini de flux, aplicația are acum o secțiune „Informații" în meniul lateral și un footer cu aceleași linkuri:

- **Ghid — cum funcționează**: o pagină care explică tot produsul (fluxul în 5 pași, FREE vs. PREMIUM, cum se calculează scorul, valoarea estimată, simulatorul, pagina live, rosterul și limitările oneste).
- **Termeni și condiții**, **Politică de confidențialitate (GDPR)**, **Politică de cookies**: modele de pornire în română, adaptate faptului că aplicația e statică (datele stau în browser, nu pe server). Fiecare are câmpuri `[completează ...]` pentru operator și o notă clară că textele trebuie revizuite de un jurist înainte de publicare.

Meniul e organizat în două grupuri (**Flux** 1–5 și **Informații**), aliniat la stânga. Paginile informative nu intră în navigarea înainte/înapoi a fluxului și nu apar în exportul PDF (se tipărește doar Raportul).

Limbajul din interfață a fost rescris ca să fie mai explicativ: hero, intro-ul formularului, stările goale din raport („aici apare... se deblochează în premium") și textele de export spun acum clar ce face fiecare parte și de ce.

## Simulator de creștere (nou)

Scorul nu mai e doar un verdict — devine un instrument interactiv. În pagina **Raport**, sub dashboard, un simulator cu parametri live (urmăritori, frecvență postări, nivel, public, ofertă, rezultate documentate) recalculează în timp real, prin motorul real din `scoring.js`:

- **scorul** (inel cu arc auriu = simulat, arc gri = profilul curent, plus delta „+13");
- **valoarea lunară estimată** pentru sponsor, cu diferența față de acum („+1.840 lei/lună");
- **sub-scorurile**, fiecare cu bară „acum → simulat";
- un **plan de 90 de zile** generat automat din diferența dintre profilul curent și cel simulat (cât să crești audiența, ce frecvență să ții, ce nivel să țintești etc.).

Butonul **„Aplică în profil"** scrie valorile simulate înapoi în formular și regenerează raportul. Totul e 100% static — recalcul instant, fără rețea. Fișier nou: `assets/js/simulator.js`.

## Structură pe pagini (nou)

Aplicația nu mai e un singur perete lung de secțiuni. E organizată în **5 pagini** navigabile din meniul lateral, fiecare glisând din dreapta la schimbare:

1. **Profil** — formularul sportivului (hero + date + generare).
2. **Raport** — dashboard, scor, strategie, brand, conținut, calendar, media kit, outreach, pachete sponsor și export PDF.
3. **Pagina Live** — pagina publică de trimis sponsorului.
4. **Roster club** — portofoliul de sportivi al clubului.
5. **Premium** — cod de acces, pachete de vânzare și comandă.

Navigarea se face din meniul numerotat din stânga sau din butoanele contextuale din josul fiecărei pagini („← Înapoi", „Continuă →"). Generarea din formular te duce automat pe pagina **Raport**; butonul de PDF blocat te duce pe **Premium**. Fluxul e gestionat de `assets/js/views.js` (un router simplu care sincronizează și hash-ul din URL, deci butoanele înainte/înapoi din browser funcționează). Animația de glisare respectă `prefers-reduced-motion`, iar la export PDF toate paginile de raport sunt forțate vizibile.

## Ce s-a îmbunătățit în această versiune

### 1. Logică
- **Scor comercial ponderat și transparent**: 5 sub-scoruri (Rezultate & credibilitate, Audiență & reach, Nivel competițional, Consistență, Ofertă pentru sponsori), fiecare 0–100, agregate ponderat. Se afișează defalcarea în dashboard.
- **Următorul pas prioritar** derivat automat din cel mai slab sub-scor, nu dintr-un text fix.
- **Estimare de valoare comercială**: reach lunar estimat + interval orientativ de preț (lei/lună) pentru un sponsor, calculat din audiență, nivel, categorie de sport și scor. Apare în dashboard, media kit, strategie și PDF.
- **Coduri premium unice per comandă** (derivate determinist din email + pachet), pe lângă codul demo de test.
- **Validare** email + telefon la comandă.

### 2. Servicii
- Strat de servicii izolat (`services.js`): `storage` sigur (nu crapă în navigare privată), `clipboard` cu fallback pentru `file://` / contexte nesecurizate, formatare `ro-RO`, validare, generatoare de linkuri.
- **Outreach acționabil**: butoane „Copiază mesajul" + „Deschide în email / WhatsApp" pre-completate.
- **Comandă trimisă real**: linkuri `mailto:` și `wa.me` către operator, cu codul de activare inclus în mesajul pentru operator.

### 3. Structură
Cod modularizat pe responsabilități (în loc de un singur `app.js` monolit):

```text
sportbrand-ai/
├── index.html
├── assets/
│   ├── css/style.css
│   └── js/
│       ├── config.js       # prețuri, coduri, brand, constante
│       ├── sports-data.js  # sporturi + profiluri pe categorie
│       ├── services.js     # storage / clipboard / format / validate / links
│       ├── scoring.js      # scor ponderat + estimare valoare
│       ├── generators.js   # tot conținutul generat
│       ├── premium.js      # stare premium + coduri unice
│       ├── pdf.js          # meta PDF
│       └── app.js          # doar wiring UI + randare
└── README.md
```

### 4. Design
- Identitate atletică nouă („scoreboard / podium"): navy de stadion, accent auriu (valoare/premium) + cyan (date/performanță), numere pe font mono.
- **Inel de scor** tip cronometru (semnătura vizuală) în locul barei plate, plus **metre de sub-scor**.
- Tipografie: Archivo (display) + Inter (body) + Space Mono (date), cu fallback pe fonturi de sistem dacă nu există internet.
- Card de valoare estimată evidențiat, price cards și pills recolorate coerent.

### 5. Altele
- **Accesibilitate**: tab-uri outreach cu ARIA corect (`aria-selected`, roving `tabindex`, navigare cu săgeți), focus vizibil, `prefers-reduced-motion` respectat.
- **SEO / meta**: Open Graph, `theme-color`, favicon SVG inline.
- Mesaje de eroare utile (copiere eșuată, navigare privată, cod invalid).
- Print / PDF A4 păstrat și adaptat.

## Roster de club (nou)

Upgrade pentru cluburi/academii: în loc de un singur profil, gestionezi un **portofoliu** de sportivi.

- **Salvează profilul curent în roster** (secțiunea „Roster de club", premium) — ține minte sportivii într-un tabel: nume, sport, scor, valoare estimată, cu acțiuni rapide (Încarcă profilul înapoi în formular / Descarcă pagina lui live / Șterge).
- **Statistici agregate**: scor mediu roster, valoare lunară totală estimată, cea mai frecventă slăbiciune din tot rosterul (pe ce dimensiune ar trebui să lucreze clubul cel mai mult).
- **„Deschide raportul de club"** → `club-report.html`, un portofoliu tipărit/exportabil PDF (buton „Print"): toți sportivii, sortați după scor, cu valoare și puncte de lucru — de trimis unui sponsor care vrea pachet pe echipă, nu pe individ.
- **„Descarcă pagini live (roster complet)"** → exportă în lot pagina live independentă pentru fiecare sportiv din roster.
- **Export / Import JSON** — plasă de siguranță, pentru backup sau mutare pe alt calculator.
- Fișiere noi: `assets/js/roster.js` (CRUD + statistici + export/import), `club-report.html` + `assets/js/club-report.js` (portofoliul de club).

**Limitare onestă:** rosterul stă doar în acest browser (localStorage) — nu se sincronizează între dispozitive. Linkul „raportului de club" poartă datele direct în URL (ca la Pagina Live), tocmai ca să funcționeze corect chiar dacă `localStorage` nu e partajat între `index.html` și `club-report.html` când sunt deschise ca fișiere locale (`file://`) — comportament care diferă între browsere. Pentru roster sincronizat pe mai multe dispozitive/conturi, e nevoie de backend.

## Pagina Live pentru Sponsori (nou)

Cea mai mare schimbare din această rundă: raportul nu mai rămâne doar un PDF pe care îl vede sportivul — devine o **pagină publică**, cu link propriu, trimisă direct sponsorului.

- **Cum funcționează:** din secțiunea „Pagina Live pentru Sponsori" (premium), butonul „Generează pagina live" codifică profilul + scorul + estimarea de valoare direct în linkul către `brand.html` (fragment `#d=...`). Nu există server, bază de date sau cont — linkul e „stateless".
- **Ce vede sponsorul:** scor + detaliere pe 5 sub-scoruri, valoare orientativă de parteneriat, bio, ce poate oferi sportivul, categorii de sponsori potrivite și un buton „Contactează pentru parteneriat" (deschide email sau telefon, dacă sportivul a completat un contact în profil).
- **„Descarcă pagină independentă (HTML)":** generează un fișier `.html` de sine stătător (CSS + conținut deja randate, fără JavaScript necesar la afișare), pe care sportivul îl poate găzdui oriunde — GitHub Pages, Netlify, propriul site — fără restul proiectului.
- Fișiere noi: `assets/js/share.js` (encode/decode + randare), `brand.html` + `assets/js/brand-view.js` (varianta „link", citește din URL).
- Am adăugat câmpuri opționale de contact (email/telefon) în formularul de profil, folosite doar pe pagina live, pentru CTA-ul sponsorului.

**Limitare onestă a acestei implementări:** linkul „live" nu e scurt și nu e permanent per atlet — datele stau chiar în URL. E suficient de bun pentru trimis direct unui sponsor (email/WhatsApp), dar pentru linkuri scurte, editabile ulterior și analytics reale (cine a deschis, cine a dat click), ai nevoie de găzduire cu backend. Vezi „Următorul upgrade recomandat".

## Acces premium

Cod demo pentru testare:

```text
LS-PREMIUM-2026
```

Flux comercial:

1. Sportivul completează profilul și primește scorul + raportul basic.
2. Alege pachetul și trimite comanda (email / WhatsApp către operator).
3. Operatorul confirmă plata și trimite codul de activare (unic per comandă).
4. Sportivul introduce codul → se deblochează raportul complet, exportul PDF și Pagina Live pentru Sponsori.

Pentru a lega comenzile de un canal real, completează `operatorEmail` / `operatorWhatsApp` în `assets/js/config.js`.

## Limitări oneste (important)

- **Gating-ul premium e pe client (localStorage). Nu e securitate reală** — cine deschide sursa poate debloca. E acceptabil pentru un MVP cu plată confirmată manual, dar pentru producție ai nevoie de un backend care emite și verifică coduri.
- **Estimările de valoare sunt orientative** (CPM asumat pentru sponsorizare sportivă locală), nu garanții. De ajustat cu date reale.
- **Conținutul de bază e generat pe reguli** (template-uri); cu backend + cheie Gemini, secțiunile cheie pot fi rescrise de AI real (vezi secțiunea dedicată).
- **Pagina Live e stateless** (datele stau în URL, nu pe server) — bun pentru trimis direct, dar fără link scurt permanent sau analytics reale fără backend.
- **Rosterul de club stă doar în acest browser** (localStorage) — nu se sincronizează între dispozitive; folosește export/import JSON pentru backup.
- Fonturile se încarcă de la Google Fonts; offline se folosesc fallback-urile de sistem.

## Următorul upgrade recomandat

- backend minim pentru coduri și validare reală;
- integrare plăți (Netopia / Stripe / WooCommerce);
- colectare cu confirmare reală (înlocuiește „fire-and-forget"-ul din Google Sheets cu un endpoint propriu care validează și răspunde), plus anti-spam;
- generarea AI live a textelor printr-un model, cu cheia API protejată server-side (necesar oricum pentru găzduire reală);
- linkuri scurte/permanente per atlet + analytics (views, click-uri „parteneriat") pentru Pagina Live;
- roster sincronizat pe cont/echipă (multi-dispozitiv) + acces per antrenor;
- profil public sportiv + dashboard pentru cluburi.
