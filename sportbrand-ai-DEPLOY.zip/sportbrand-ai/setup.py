#!/usr/bin/env python3
"""
SportBrand AI — script de pregătire pentru lansare.

Ce face:
  1. Înlocuiește placeholder-ul REPLACE-CU-DOMENIUL-TAU cu domeniul tău real,
     în toate fișierele care îl conțin (index.html, robots.txt, sitemap.xml).
  2. Opțional, scrie endpoint-ul Apps Script în assets/js/config.js.
  3. Verifică la final că nu a mai rămas niciun placeholder.

Utilizare:
    python3 setup.py --domeniu https://sportbrand.ro
    python3 setup.py --domeniu https://user.github.io/sportbrand-ai \
                     --endpoint https://script.google.com/macros/s/XXXX/exec

Dacă publici într-un SUBFOLDER (ex. GitHub Pages project site), dă domeniul
complet, inclusiv subfolderul, fără slash final.
"""

import argparse
import pathlib
import re
import sys

PLACEHOLDER = "https://REPLACE-CU-DOMENIUL-TAU"
ROOT = pathlib.Path(__file__).parent

# Fișierele care pot conține placeholder-ul de domeniu.
DOMAIN_FILES = ["index.html", "robots.txt", "sitemap.xml"]
CONFIG_FILE = "assets/js/config.js"


def set_domain(domain: str) -> int:
    domain = domain.rstrip("/")
    if not domain.startswith("http"):
        print(f"EROARE: domeniul trebuie să înceapă cu http:// sau https:// (ai dat: {domain})")
        sys.exit(1)

    changed = 0
    for name in DOMAIN_FILES:
        path = ROOT / name
        if not path.exists():
            print(f"  (sar peste {name} — nu există)")
            continue
        text = path.read_text(encoding="utf-8")
        if PLACEHOLDER not in text:
            print(f"  = {name} (nimic de înlocuit)")
            continue
        count = text.count(PLACEHOLDER)
        path.write_text(text.replace(PLACEHOLDER, domain), encoding="utf-8")
        print(f"  ✓ {name} — {count} înlocuiri")
        changed += count
    return changed


def set_endpoint(endpoint: str) -> None:
    path = ROOT / CONFIG_FILE
    if not path.exists():
        print(f"EROARE: nu găsesc {CONFIG_FILE}")
        sys.exit(1)
    if "/exec" not in endpoint:
        print("ATENȚIE: URL-ul Apps Script ar trebui să se termine în /exec.")

    text = path.read_text(encoding="utf-8")
    new_text, n = re.subn(
        r"sheetsEndpoint:\s*'[^']*'",
        f"sheetsEndpoint: '{endpoint}'",
        text,
        count=1,
    )
    if n == 0:
        print(f"EROARE: nu am găsit câmpul sheetsEndpoint în {CONFIG_FILE}")
        sys.exit(1)
    path.write_text(new_text, encoding="utf-8")
    print(f"  ✓ {CONFIG_FILE} — endpoint backend setat")


def verify() -> bool:
    print("\nVerificare finală:")
    # Fișierele care chiar contează: cele servite utilizatorului.
    # Documentația (README/LANSARE) menționează placeholder-ul ca exemplu — normal.
    DOCS = {"README.md", "LANSARE.md"}
    leftovers = []
    doc_mentions = []
    for path in ROOT.rglob("*"):
        if not path.is_file() or path.suffix in {".png", ".zip", ".pyc"}:
            continue
        if path.name == "setup.py":
            continue
        try:
            text = path.read_text(encoding="utf-8")
        except (UnicodeDecodeError, PermissionError):
            continue
        if "REPLACE-CU-DOMENIUL-TAU" in text:
            rel = path.relative_to(ROOT)
            if path.name in DOCS:
                doc_mentions.append(rel)
            else:
                leftovers.append(rel)

    if leftovers:
        print("  ✗ Au mai rămas placeholdere de domeniu în fișiere LIVE:")
        for f in leftovers:
            print(f"      - {f}")
        return False

    print("  ✓ Niciun placeholder rămas în fișierele publicate.")
    if doc_mentions:
        print(f"    (menționat doar în documentație: {', '.join(str(f) for f in doc_mentions)} — normal)")

    cfg = (ROOT / CONFIG_FILE).read_text(encoding="utf-8")
    m = re.search(r"sheetsEndpoint:\s*'([^']*)'", cfg)
    endpoint = m.group(1) if m else ""
    if endpoint:
        print(f"  ✓ Backend configurat: {endpoint[:50]}…")
    else:
        print("  ! Backend NEconfigurat (sheetsEndpoint gol).")
        print("    Aplicația va funcționa static: fără colectare, coduri pe server,")
        print("    linkuri scurte, analytics, consolă operator sau AI real.")

    # Avertismente utile înainte de lansare
    if "schimba-cheia-asta" in (ROOT / "google-apps-script.gs").read_text(encoding="utf-8"):
        print("  ! ADMIN_KEY e încă valoarea implicită în google-apps-script.gs — schimb-o.")
    if re.search(r"operatorEmail:\s*''", cfg) and re.search(r"operatorWhatsApp:\s*''", cfg):
        print("  ! operatorEmail / operatorWhatsApp sunt goale în config.js —")
        print("    comenzile nu vor avea unde să ajungă.")
    return True


def main() -> None:
    parser = argparse.ArgumentParser(description="Pregătește SportBrand AI pentru lansare.")
    parser.add_argument("--domeniu", help="URL-ul public, ex: https://sportbrand.ro")
    parser.add_argument("--endpoint", help="URL-ul Apps Script Web App (se termină în /exec)")
    parser.add_argument("--verifica", action="store_true", help="Doar verifică, nu modifica nimic")
    args = parser.parse_args()

    if args.verifica:
        sys.exit(0 if verify() else 1)

    if not args.domeniu and not args.endpoint:
        parser.print_help()
        print("\nExemplu:\n  python3 setup.py --domeniu https://sportbrand.ro")
        sys.exit(1)

    if args.domeniu:
        print(f"Setez domeniul: {args.domeniu}")
        set_domain(args.domeniu)

    if args.endpoint:
        print(f"\nSetez endpoint-ul backend: {args.endpoint}")
        set_endpoint(args.endpoint)

    ok = verify()
    print("\nGata." if ok else "\nGata, dar vezi avertismentele de mai sus.")
    print("Următorul pas: citește LANSARE.md")


if __name__ == "__main__":
    main()
