/* SportBrand AI — service worker.

   Strategii, alese ca să NU blocheze utilizatorii pe versiuni vechi:
   - HTML (navigări): NETWORK-FIRST. Dacă există net, primești mereu ultima
     versiune; offline, cade pe copia din cache.
   - Assets (CSS/JS/imagini): CACHE-FIRST, dar versionate prin CACHE_NAME.
     Rapide offline, iar la un release nou schimbi versiunea și se reîmprospătează.
   - Backend (Apps Script / Google APIs): NICIODATĂ din cache — date live.

   IMPORTANT LA FIECARE RELEASE: incrementează CACHE_VERSION mai jos.
   Altfel utilizatorii pot rămâne cu fișiere vechi în cache. */

const CACHE_VERSION = 'v1';
const CACHE_NAME = `sportbrand-${CACHE_VERSION}`;

// Fișierele de bază, puse în cache la instalare (app shell).
const PRECACHE = [
  './',
  './index.html',
  './brand.html',
  './club-report.html',
  './assets/css/style.css',
  './assets/js/config.js',
  './assets/js/sports-data.js',
  './assets/js/services.js',
  './assets/js/collect.js',
  './assets/js/api.js',
  './assets/js/scoring.js',
  './assets/js/generators.js',
  './assets/js/share.js',
  './assets/js/roster.js',
  './assets/js/premium.js',
  './assets/js/pdf.js',
  './assets/js/views.js',
  './assets/js/simulator.js',
  './assets/js/app.js',
  './assets/js/pwa.js',
  './assets/js/brand-view.js',
  './assets/js/club-report.js',
  './assets/img/icon-192.png',
  './assets/img/icon-512.png',
  './assets/img/icon-maskable-512.png',
  './assets/img/apple-touch-icon.png',
  './manifest.webmanifest'
];

self.addEventListener('install', (event) => {
  event.waitUntil(
    caches.open(CACHE_NAME)
      // addAll e „totul sau nimic”: dacă un fișier lipsește, instalarea eșuează.
      // Punem fiecare fișier separat, ca o resursă lipsă să nu strice tot SW-ul.
      .then((cache) => Promise.all(
        PRECACHE.map((url) => cache.add(url).catch(() => null))
      ))
      .then(() => self.skipWaiting())
  );
});

self.addEventListener('activate', (event) => {
  event.waitUntil(
    caches.keys()
      .then((keys) => Promise.all(
        keys.filter((k) => k.startsWith('sportbrand-') && k !== CACHE_NAME)
            .map((k) => caches.delete(k))
      ))
      .then(() => self.clients.claim())
  );
});

// Permite paginii să forțeze activarea unei versiuni noi.
self.addEventListener('message', (event) => {
  if (event.data === 'SKIP_WAITING') self.skipWaiting();
});

function isBackend(url) {
  return url.hostname.indexOf('script.google.com') !== -1 ||
         url.hostname.indexOf('script.googleusercontent.com') !== -1 ||
         url.hostname.indexOf('googleapis.com') !== -1;
}

self.addEventListener('fetch', (event) => {
  const req = event.request;
  if (req.method !== 'GET') return; // POST-urile (colectare, log) trec direct

  const url = new URL(req.url);

  // Backend/date live: mereu din rețea, niciodată din cache.
  if (isBackend(url)) return;

  // Navigări (HTML): network-first.
  if (req.mode === 'navigate') {
    event.respondWith(
      fetch(req)
        .then((res) => {
          const copy = res.clone();
          caches.open(CACHE_NAME).then((c) => c.put(req, copy)).catch(() => {});
          return res;
        })
        .catch(() => caches.match(req).then((hit) => hit || caches.match('./index.html')))
    );
    return;
  }

  // Restul (CSS/JS/imagini/fonturi): cache-first, cu completare în fundal.
  event.respondWith(
    caches.match(req).then((hit) => {
      if (hit) return hit;
      return fetch(req).then((res) => {
        // cache doar răspunsuri valide, de același origin sau fonturi Google
        const ok = res && (res.status === 200 || res.type === 'opaque');
        if (ok) {
          const copy = res.clone();
          caches.open(CACHE_NAME).then((c) => c.put(req, copy)).catch(() => {});
        }
        return res;
      }).catch(() => hit);
    })
  );
});
