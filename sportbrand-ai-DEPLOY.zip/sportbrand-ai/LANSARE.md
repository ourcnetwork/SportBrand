# Manual de lansare — SportBrand AI

De la fișierele astea la un produs public, în ~30 de minute.

Aplicația funcționează în **trei trepte**. Poți opri oriunde:

| Treaptă | Ce obții | Cât durează |
|---|---|---|
| **1. Doar site** | Aplicația publică: scor, simulator, raport, PDF, roster, pagini live. Instalabilă pe telefon (PWA). | ~10 min |
| **2. + Backend** | Colectare comenzi în Google Sheets, coduri premium validate pe server, linkuri scurte, analytics, consolă operator. | +15 min |
| **3. + AI real** | Rescriere cu AI a strategiei, brandului și emailurilor către sponsori. | +5 min |

> **Important:** treapta 1 funcționează perfect singură. Fără backend, aplicația cade elegant pe varianta statică — nimic nu se strică, doar lipsesc funcțiile de treapta 2 și 3.

---

## Treapta 1 — Publicarea site-ului

### 1.1. Alege unde publici

Ai nevoie de o găzduire **HTTPS** (obligatoriu pentru PWA și service worker). Cele gratuite sunt suficiente:

- **GitHub Pages** — gratuit, bun dacă folosești deja Git.
- **Netlify / Vercel** — gratuit, cel mai simplu: tragi folderul în browser și gata.
- **Găzduire proprie** — orice hosting cu HTTPS și domeniu propriu.

> ⚠️ **Nu merge din `file://`** (dublu-click pe index.html). Local, aplicația se vede, dar service worker-ul, instalarea și apelurile către backend sunt blocate de browser. Pentru test local: `python3 -m http.server 8000` și deschide `http://localhost:8000`.

### 1.2. Setează domeniul (o comandă)

Aplicația conține un placeholder pentru domeniu (în meta SEO, `robots.txt`, `sitemap.xml`). Îl înlocuiești automat:

```bash
python3 setup.py --domeniu https://domeniul-tau.ro
```

Dacă publici într-un **subfolder** (tipic la GitHub Pages), dă calea completă:

```bash
python3 setup.py --domeniu https://username.github.io/sportbrand-ai
```

Scriptul îți confirmă câte înlocuiri a făcut și verifică la final că n-a rămas niciun placeholder.

> Fără pasul ăsta, aplicația **funcționează**, dar linkul preview pe WhatsApp/Facebook și indexarea Google nu vor merge corect.

### 1.3. Urcă fișierele

**Netlify (cel mai rapid):**
1. Intră pe [app.netlify.com/drop](https://app.netlify.com/drop).
2. Trage folderul `sportbrand-ai` în pagină.
3. Primești imediat un URL public. Gata.

**GitHub Pages:**
1. Creează un repository nou, urcă în el conținutul folderului.
2. Settings → Pages → Source: `main` / root.
3. După ~1 minut, site-ul e la `https://username.github.io/nume-repo`.

### 1.4. Verifică

Deschide site-ul pe telefon. Ar trebui să:
- se încarce corect și să arate meniul lateral;
- îți propună **„Adaugă pe ecranul principal"** (Android/Chrome) — sau, pe iPhone: Share (□↑) → Add to Home Screen;
- funcționeze **offline** după prima vizită (pune telefonul pe avion și reîncarcă: scorul, simulatorul și rosterul merg).

Codul demo pentru a testa funcțiile premium: `LS-PREMIUM-2026`

**Aici te poți opri.** Ai un produs public, funcțional, instalabil.

---

## Treapta 2 — Backend (Google Sheets + Apps Script)

Gratuit, găzduit de Google. Deblochează: colectarea comenzilor, codurile premium validate pe server, linkurile scurte, analytics și consola operatorului.

### 2.1. Creează Spreadsheet-ul și scriptul

1. Intră pe [sheets.google.com](https://sheets.google.com) → **Blank spreadsheet**.
2. Meniu: **Extensions → Apps Script**.
3. Șterge tot codul din editor și lipește **întreg** conținutul fișierului `google-apps-script.gs`.

### 2.2. Schimbă cheia de operator

În codul lipit, la început, găsești:

```javascript
var ADMIN_KEY = 'schimba-cheia-asta';
```

Înlocuiește cu o parolă a ta, lungă și greu de ghicit. **Ține minte valoarea** — o vei introduce în consola operatorului.

### 2.3. Publică scriptul

1. Buton **Deploy** (dreapta sus) → **New deployment**.
2. La „Select type" (roata dințată) → **Web app**.
3. Setează:
   - **Execute as:** `Me`
   - **Who has access:** `Anyone`
4. **Deploy** → Google îți cere permisiuni → acceptă (e scriptul tău, pe contul tău).
5. Copiază **Web app URL** — se termină în `/exec`.

> La prima autorizare, Google afișează un avertisment („Google hasn't verified this app"). E normal pentru scripturile proprii: **Advanced → Go to (unsafe)**.

### 2.4. Conectează aplicația la backend

```bash
python3 setup.py --endpoint https://script.google.com/macros/s/XXXXX/exec
```

Sau manual, în `assets/js/config.js`:

```javascript
collect: {
  sheetsEndpoint: 'https://script.google.com/macros/s/XXXXX/exec',
  ...
}
```

**Re-urcă fișierele** pe găzduire.

### 2.5. Adaugă coduri premium

În Spreadsheet apare automat fila **`Codes`** după prima utilizare (sau o creezi tu, cu antetul `code | note | active`).

Ca să dai acces cuiva după ce a plătit: adaugi un rând cu codul. Ca să-l anulezi: pui `active = FALSE`.

| code | note | active |
|---|---|---|
| LS-A1B2-C3D4 | Andrei P. — plătit 399 lei | TRUE |
| LS-X9Y8-Z7W6 | anulat, rambursat | FALSE |

Codul pe care îl trimiți clientului îl găsești **în mesajul de comandă** pe care ți-l trimite el pe email/WhatsApp (aplicația îl generează unic pentru fiecare comandă).

### 2.6. Consola operatorului

Deschide `https://domeniul-tau.ro/admin.html`, introdu cheia de la 2.2.

Vezi: comenzi, lead-uri, coduri active, și — cel mai important — **ce pagini live au primit click pe „Contact"**. Un click acolo = un sponsor interesat. Ăla e momentul să suni atletul.

---

## Treapta 3 — AI real (Gemini)

### 3.1. Ia o cheie gratuită

1. Intră pe [aistudio.google.com/apikey](https://aistudio.google.com/apikey).
2. **Create API key** → copiază cheia.

### 3.2. Pune cheia în Apps Script (nu în cod!)

1. În editorul Apps Script: **Project Settings** (roata dințată, stânga).
2. Jos, **Script properties** → **Add script property**:
   - **Property:** `GEMINI_API_KEY`
   - **Value:** cheia copiată
3. **Save script properties**.
4. **Deploy → Manage deployments → Edit (creion) → Version: New version → Deploy.**

> Cheia stă **doar pe server**. Nu apare niciodată în codul pe care îl văd vizitatorii.

### 3.3. Testează

Intră în aplicație, activează premium (cod demo sau al tău), mergi la **Raport** → butonul **„✦ Rescrie cu AI"** de la Strategie. În 2–5 secunde textul e înlocuit cu unul generat pe profilul concret.

Dacă apare „Backend-ul nu are cheie AI" → ai uitat pasul 3.2 sau nu ai făcut **New version** la deploy (pasul 4).

---

## Checklist final înainte de promovare

- [ ] Site-ul se încarcă pe HTTPS
- [ ] `python3 setup.py --verifica` nu raportează placeholdere
- [ ] Trimite-ți linkul pe WhatsApp: apare imaginea de preview (cardul auriu cu scor)?
- [ ] Pe telefon: se instalează pe ecranul principal?
- [ ] Offline: scorul și simulatorul merg?
- [ ] Codul demo `LS-PREMIUM-2026` deblochează premium
- [ ] Ai schimbat `ADMIN_KEY` din valoarea implicită
- [ ] Ai completat datele operatorului în `assets/js/config.js` (`operatorEmail`, `operatorWhatsApp`) — altfel comenzile nu au unde să ajungă
- [ ] Ai completat câmpurile `[completează ...]` din paginile Termeni / Confidențialitate / Cookies
- [ ] Ai trimis `sitemap.xml` în [Google Search Console](https://search.google.com/search-console)

---

## Actualizări ulterioare

Când modifici fișiere și re-urci, utilizatorii care au instalat aplicația pot rămâne cu versiunea veche în cache. Ca să eviți asta:

**Incrementează versiunea în `sw.js`:**

```javascript
const CACHE_VERSION = 'v2';   // era 'v1'
```

Service worker-ul folosește *network-first* pe HTML (deci pagina se actualizează oricum când există net), dar la schimbări de CSS/JS versiunea nouă e obligatorie.

---

## Probleme frecvente

**„Nu apare butonul de instalare"**
Verifică: ești pe HTTPS? Ai deja aplicația instalată? Pe iOS nu există buton automat — instalarea se face manual din Share → Add to Home Screen.

**„Comenzile nu ajung în Sheet"**
Cel mai des: n-ai făcut **New version** la deploy după o modificare. Testează endpoint-ul deschizându-l direct în browser — trebuie să răspundă cu un JSON `{"ok":true,...}`.

**„Consola zice «Cheie respinsă»"**
Cheia din `admin.html` trebuie să fie identică cu `ADMIN_KEY` din Apps Script, iar deploy-ul trebuie re-publicat după ce ai schimbat-o.

**„AI-ul nu răspunde"**
Cotele free-tier Gemini sunt limitate. Dacă generezi des, poți primi eroare de cotă — textul pe reguli rămâne valabil ca rezervă.

---

## Ce rămâne, onest, în afara acestui setup

- **Plăți automate.** Fluxul e plată manuală + cod trimis de tine. Pentru plată automată (card, Netopia/Stripe) ai nevoie de un backend real, nu de Apps Script.
- **Securitate reală.** Codurile validate pe server sunt un pas mare înainte, dar `ADMIN_KEY` nu e autentificare adevărată (fără utilizatori, sesiuni, permisiuni). Nu ține date sensibile în consolă.
- **Scală.** Apps Script e lent (~1–2s/cerere) și are cote zilnice. E potrivit pentru zeci–sute de utilizatori, nu pentru mii.
- **Distribuția.** PWA-ul îți păstrează utilizatorii, dar nu ți-i aduce. Asta rămâne partea ta de treabă.
